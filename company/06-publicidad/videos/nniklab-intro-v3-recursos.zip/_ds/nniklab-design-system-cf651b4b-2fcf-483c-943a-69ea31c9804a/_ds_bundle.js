/* @ds-bundle: {"format":4,"namespace":"NniklabDesignSystem_cf651b","components":[{"name":"ChartPanel","sourcePath":"components/cards/ChartPanel.jsx"},{"name":"PipelineStep","sourcePath":"components/cards/PipelineStep.jsx"},{"name":"PipelineArrow","sourcePath":"components/cards/PipelineStep.jsx"},{"name":"ServiceCard","sourcePath":"components/cards/ServiceCard.jsx"},{"name":"StatTile","sourcePath":"components/cards/StatTile.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Eyebrow","sourcePath":"components/core/Eyebrow.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Logo","sourcePath":"components/core/Logo.jsx"},{"name":"ServiceRow","sourcePath":"components/lists/ServiceRow.jsx"},{"name":"StepItem","sourcePath":"components/lists/StepItem.jsx"},{"name":"Footer","sourcePath":"components/navigation/Footer.jsx"},{"name":"NavBar","sourcePath":"components/navigation/NavBar.jsx"}],"sourceHashes":{"components/cards/ChartPanel.jsx":"96bba86c00f4","components/cards/PipelineStep.jsx":"2208308aa859","components/cards/ServiceCard.jsx":"f22f05f0fed8","components/cards/StatTile.jsx":"d760330eb2c9","components/core/Badge.jsx":"6fa9ac4993d5","components/core/Button.jsx":"f47c63f4203b","components/core/Eyebrow.jsx":"e57c53229be1","components/core/IconButton.jsx":"dc0119c7b61a","components/core/Logo.jsx":"0077d82de63b","components/lists/ServiceRow.jsx":"306f8295cc9b","components/lists/StepItem.jsx":"cad0ef640735","components/navigation/Footer.jsx":"ee11c47066ae","components/navigation/NavBar.jsx":"d096a8e0d3ab","ui_kits/web/LandingBase.jsx":"810cf060d493","ui_kits/web/LandingTecnico.jsx":"b0bf96b64285"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.NniklabDesignSystem_cf651b = window.NniklabDesignSystem_cf651b || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/cards/PipelineStep.jsx
try { (() => {
function PipelineStep({
  index,
  tag,
  title,
  active = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      background: active ? 'var(--nk-lima)' : 'var(--nk-grafito)',
      border: '1px solid ' + (active ? 'var(--nk-lima)' : 'var(--nk-linea)'),
      borderRadius: 10,
      padding: '22px 24px 26px',
      minHeight: 122,
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-tecnica)',
      fontSize: 12,
      letterSpacing: '0.5px',
      color: active ? 'var(--nk-grafito)' : 'var(--nk-gris-texto)',
      opacity: active ? .75 : 1
    }
  }, index, " \xB7 ", tag), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-texto)',
      fontWeight: 600,
      fontSize: 22,
      lineHeight: 1.2,
      color: active ? 'var(--nk-grafito)' : 'var(--nk-hueso)',
      marginTop: 10
    }
  }, title));
}
function PipelineArrow() {
  return /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      color: 'var(--nk-lima)',
      fontSize: 24,
      fontFamily: 'var(--font-texto)',
      flex: 'none',
      padding: '0 14px'
    }
  }, "\u2192");
}
Object.assign(__ds_scope, { PipelineStep, PipelineArrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/PipelineStep.jsx", error: String((e && e.message) || e) }); }

// components/cards/ServiceCard.jsx
try { (() => {
function ServiceCard({
  index,
  title,
  description
}) {
  const [h, setH] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      background: 'var(--nk-superficie)',
      border: '1px solid ' + (h ? 'var(--nk-acero)' : 'var(--nk-linea)'),
      borderRadius: 20,
      padding: '40px 40px 44px',
      display: 'flex',
      flexDirection: 'column',
      boxSizing: 'border-box',
      transition: 'border-color var(--dur-base) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-texto)',
      fontWeight: 600,
      fontSize: 18,
      color: 'var(--nk-lima)'
    }
  }, index), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-texto)',
      fontWeight: 500,
      fontSize: 30,
      letterSpacing: '-0.3px',
      lineHeight: 1.2,
      color: 'var(--nk-hueso)',
      marginTop: 64
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-texto)',
      fontSize: 17,
      lineHeight: 1.65,
      color: 'var(--nk-gris-texto)',
      marginTop: 14,
      textWrap: 'pretty'
    }
  }, description));
}
Object.assign(__ds_scope, { ServiceCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/ServiceCard.jsx", error: String((e && e.message) || e) }); }

// components/cards/StatTile.jsx
try { (() => {
function StatTile({
  label,
  value,
  accent = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--nk-grafito)',
      borderRadius: 12,
      padding: '20px 20px 22px',
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-texto)',
      fontSize: 13,
      color: 'var(--nk-gris-texto)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-texto)',
      fontWeight: 500,
      fontSize: 24,
      color: accent ? 'var(--nk-lima)' : 'var(--nk-hueso)'
    }
  }, value));
}
Object.assign(__ds_scope, { StatTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/StatTile.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function Badge({
  children,
  tone = 'accent',
  shape = 'pill'
}) {
  const t = tone === 'neutral' ? {
    background: 'var(--nk-superficie-2)',
    color: 'var(--nk-hueso)'
  } : tone === 'solid' ? {
    background: 'var(--nk-lima)',
    color: 'var(--nk-grafito)'
  } : {
    background: 'var(--nk-lima-tint)',
    color: 'var(--nk-lima)'
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      height: 28,
      padding: '0 14px',
      borderRadius: shape === 'square' ? 0 : 999,
      fontFamily: 'var(--font-texto)',
      fontSize: 14,
      fontWeight: 600,
      whiteSpace: 'nowrap',
      ...t
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/cards/ChartPanel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ChartPanel({
  title = 'Procesos automatizados',
  badge = 'En tiempo real',
  bars = [42, 58, 50, 70, 64, 83, 76, 100],
  stats = [{
    label: 'Reportes',
    value: 'Automáticos'
  }, {
    label: 'Fuentes de datos',
    value: 'Integradas',
    accent: true
  }],
  chartHeight = 240
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--nk-superficie)',
      border: '1px solid var(--nk-linea)',
      borderRadius: 24,
      padding: 36,
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-texto)',
      fontSize: 18,
      color: 'var(--nk-gris-texto)'
    }
  }, title), badge && /*#__PURE__*/React.createElement(__ds_scope.Badge, null, badge)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 14,
      height: chartHeight,
      marginTop: 24
    }
  }, bars.map((b, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      height: b + '%',
      background: i === bars.length - 1 ? 'var(--nk-lima)' : 'var(--nk-linea)',
      borderRadius: '4px 4px 0 0'
    }
  }))), stats && stats.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(' + stats.length + ',minmax(0,1fr))',
      gap: 14,
      marginTop: 24
    }
  }, stats.map((s, i) => /*#__PURE__*/React.createElement(__ds_scope.StatTile, _extends({
    key: i
  }, s)))));
}
Object.assign(__ds_scope, { ChartPanel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/ChartPanel.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
const SIZES = {
  lg: {
    height: 58,
    padding: '0 34px',
    fontSize: 18
  },
  md: {
    height: 48,
    padding: '0 26px',
    fontSize: 16
  },
  sm: {
    height: 40,
    padding: '0 20px',
    fontSize: 14
  }
};
const VARIANTS = {
  primary: {
    background: 'var(--nk-lima)',
    color: 'var(--nk-grafito)',
    border: '1px solid var(--nk-lima)',
    fontWeight: 600
  },
  secondary: {
    background: 'transparent',
    color: 'var(--nk-hueso)',
    border: '1px solid var(--nk-linea)',
    fontWeight: 500
  },
  dark: {
    background: 'var(--nk-grafito)',
    color: 'var(--nk-hueso)',
    border: '1px solid var(--nk-grafito)',
    fontWeight: 500
  },
  outlineAccent: {
    background: 'transparent',
    color: 'var(--nk-lima)',
    border: '1px solid var(--nk-lima)',
    fontWeight: 600
  }
};
function Button({
  variant = 'primary',
  size = 'md',
  shape = 'pill',
  arrow = false,
  disabled = false,
  href,
  onClick,
  children,
  style
}) {
  const [h, setH] = React.useState(false);
  const [p, setP] = React.useState(false);
  const v = VARIANTS[variant] || VARIANTS.primary;
  const s = SIZES[size] || SIZES.md;
  const hover = h && !disabled ? variant === 'primary' ? {
    background: '#D4FA5C',
    borderColor: '#D4FA5C'
  } : variant === 'dark' ? {
    background: '#1A1D22'
  } : {
    borderColor: variant === 'outlineAccent' ? '#D4FA5C' : 'var(--nk-acero)',
    background: variant === 'outlineAccent' ? 'var(--nk-lima-tint)' : 'rgba(255,255,255,.03)'
  } : {};
  const Tag = href ? 'a' : 'button';
  return /*#__PURE__*/React.createElement(Tag, {
    href: href,
    onClick: disabled ? undefined : onClick,
    disabled: disabled,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => {
      setH(false);
      setP(false);
    },
    onMouseDown: () => setP(true),
    onMouseUp: () => setP(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      boxSizing: 'border-box',
      fontFamily: 'var(--font-texto)',
      lineHeight: 1,
      whiteSpace: 'nowrap',
      textDecoration: 'none',
      cursor: disabled ? 'not-allowed' : 'pointer',
      borderRadius: shape === 'square' ? 0 : 999,
      transition: 'background var(--dur-fast) var(--ease-out),border-color var(--dur-fast) var(--ease-out),transform var(--dur-fast)',
      opacity: disabled ? .4 : 1,
      transform: p ? 'translateY(1px)' : 'none',
      ...s,
      ...v,
      ...hover,
      ...style
    }
  }, children, arrow && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true"
  }, "\u2192"));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Eyebrow.jsx
try { (() => {
function Eyebrow({
  children,
  kind = 'caps',
  onLight = false,
  cursor = false
}) {
  const color = onLight ? 'var(--nk-lima-oscuro)' : 'var(--nk-lima)';
  const base = {
    fontSize: 13,
    lineHeight: 1.4,
    letterSpacing: kind === 'caps' ? '2px' : '1px',
    color,
    display: 'inline-flex',
    alignItems: 'center',
    gap: 6
  };
  if (kind === 'caps') return /*#__PURE__*/React.createElement("span", {
    style: {
      ...base,
      fontFamily: 'var(--font-texto)',
      fontWeight: 600,
      textTransform: 'uppercase'
    }
  }, children);
  const pre = kind === 'prompt' ? '> ' : kind === 'comment' ? '// ' : '';
  return /*#__PURE__*/React.createElement("span", {
    style: {
      ...base,
      fontFamily: 'var(--font-tecnica)',
      fontWeight: 400,
      gap: 0
    }
  }, pre, children, cursor && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      width: 9,
      height: 15,
      background: color,
      marginLeft: 4
    }
  }));
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function IconButton({
  glyph = '↗',
  size = 48,
  label = 'Abrir',
  onClick,
  active = false
}) {
  const [h, setH] = React.useState(false);
  const on = h || active;
  return /*#__PURE__*/React.createElement("button", {
    "aria-label": label,
    onClick: onClick,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      width: size,
      height: size,
      borderRadius: 999,
      flex: 'none',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: on ? 'var(--nk-lima)' : 'transparent',
      color: on ? 'var(--nk-grafito)' : 'var(--nk-hueso)',
      border: '1px solid ' + (on ? 'var(--nk-lima)' : 'var(--nk-linea)'),
      fontFamily: 'var(--font-texto)',
      fontSize: Math.round(size * 0.36),
      cursor: 'pointer',
      transition: 'all var(--dur-fast) var(--ease-out)'
    }
  }, glyph);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Logo.jsx
try { (() => {
const FILES = {
  oscuro: 'nniklab-logo-oscuro.svg',
  claro: 'nniklab-logo-claro.svg',
  lima: 'nniklab-logo-mono-negro.svg',
  monoBlanco: 'nniklab-logo-mono-blanco.svg',
  monoNegro: 'nniklab-logo-mono-negro.svg'
};
const DESC = {
  oscuro: 'nniklab-logo-descriptor-oscuro.svg',
  claro: 'nniklab-logo-descriptor-claro.svg',
  lima: 'nniklab-logo-descriptor-lima.svg'
};
const ICON = {
  oscuro: 'nniklab-icono-ni.svg',
  claro: 'nniklab-icono-ni-claro.svg',
  lima: 'nniklab-icono-ni-lima.svg',
  redondo: 'nniklab-icono-ni-redondo.svg',
  cuadrado: 'nniklab-icono-ni-cuadrado.svg'
};
function Logo({
  on = 'oscuro',
  type = 'wordmark',
  height = 28,
  basePath = 'assets/logo/'
}) {
  const map = type === 'icon' ? ICON : type === 'descriptor' ? DESC : FILES;
  const file = map[on] || Object.values(map)[0];
  return /*#__PURE__*/React.createElement("img", {
    src: basePath + file,
    alt: "nniklab",
    style: {
      height,
      width: 'auto',
      display: 'block'
    }
  });
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Logo.jsx", error: String((e && e.message) || e) }); }

// components/lists/ServiceRow.jsx
try { (() => {
function ServiceRow({
  index,
  title,
  description,
  onClick
}) {
  const [h, setH] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    onClick: onClick,
    style: {
      display: 'grid',
      gridTemplateColumns: '120px minmax(0,1fr) minmax(0,1fr) 48px',
      alignItems: 'center',
      gap: 24,
      padding: '34px 0',
      borderBottom: '1px solid var(--nk-linea)',
      cursor: onClick ? 'pointer' : 'default'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-tecnica)',
      fontSize: 18,
      color: 'var(--nk-lima)'
    }
  }, index), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-titulos)',
      fontWeight: 500,
      fontSize: 36,
      letterSpacing: '-1px',
      lineHeight: 1.1,
      color: h ? 'var(--nk-lima)' : 'var(--nk-hueso)',
      transition: 'color var(--dur-fast)'
    }
  }, title), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-texto)',
      fontSize: 17,
      lineHeight: 1.55,
      color: 'var(--nk-gris-texto)'
    }
  }, description), /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    label: 'Ver ' + title,
    active: h
  }));
}
Object.assign(__ds_scope, { ServiceRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/lists/ServiceRow.jsx", error: String((e && e.message) || e) }); }

// components/lists/StepItem.jsx
try { (() => {
function StepItem({
  step,
  title,
  description,
  active = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '3px solid ' + (active ? 'var(--nk-lima-oscuro)' : 'var(--nk-grafito)'),
      paddingTop: 24,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-texto)',
      fontSize: 15,
      color: 'var(--nk-acero)'
    }
  }, step), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-texto)',
      fontWeight: 500,
      fontSize: 28,
      letterSpacing: '-0.3px',
      color: 'var(--nk-grafito)',
      marginTop: 6
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-texto)',
      fontSize: 17,
      lineHeight: 1.55,
      color: 'var(--nk-acero)',
      marginTop: 10
    }
  }, description));
}
Object.assign(__ds_scope, { StepItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/lists/StepItem.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Footer.jsx
try { (() => {
function Footer({
  style = 'base',
  phone = '+593 99 578 4113',
  email = 'nniklab@outlook.com',
  logoBasePath = 'assets/logo/'
}) {
  const tec = style === 'tecnico';
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--nk-grafito)',
      borderTop: tec ? '1px solid var(--nk-linea)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1264,
      margin: '0 auto',
      padding: tec ? '40px 24px' : '56px 24px 60px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: tec ? 'center' : 'flex-start',
      gap: 24,
      flexWrap: 'wrap',
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: tec ? 'row' : 'column',
      alignItems: tec ? 'center' : 'flex-start',
      gap: tec ? 24 : 12
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    height: tec ? 24 : 28,
    basePath: logoBasePath
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-texto)',
      fontSize: tec ? 14 : 16,
      color: 'var(--nk-gris-texto)'
    }
  }, "AI, Data & Automation")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: tec ? 'row' : 'column',
      alignItems: 'flex-end',
      gap: tec ? 20 : 8,
      fontFamily: tec ? 'var(--font-tecnica)' : 'var(--font-texto)',
      fontSize: tec ? 14 : 16,
      color: 'var(--nk-gris-texto)'
    }
  }, /*#__PURE__*/React.createElement("span", null, phone), tec && /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("a", {
    href: 'mailto:' + email,
    style: {
      color: 'var(--nk-gris-texto)'
    }
  }, email))));
}
Object.assign(__ds_scope, { Footer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Footer.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavBar.jsx
try { (() => {
function NavBar({
  style = 'base',
  links,
  cta,
  current,
  onNavigate,
  onCta,
  logoBasePath = 'assets/logo/'
}) {
  const tec = style === 'tecnico';
  const items = links || (tec ? ['/servicios', '/proceso', '/casos', '/contacto'] : ['Servicios', 'Cómo trabajamos', 'Casos', 'Contacto']);
  const [hov, setHov] = React.useState(null);
  return /*#__PURE__*/React.createElement("header", {
    style: {
      height: 88,
      borderBottom: '1px solid var(--nk-linea)',
      background: 'var(--nk-grafito)',
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxWidth: 1264,
      margin: '0 auto',
      padding: '0 24px',
      display: 'grid',
      gridTemplateColumns: '1fr auto 1fr',
      alignItems: 'center',
      gap: 24,
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("a", {
    onClick: () => onNavigate && onNavigate(null),
    style: {
      cursor: 'pointer',
      justifySelf: 'start'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    height: 28,
    basePath: logoBasePath
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: tec ? 36 : 40
    }
  }, items.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    onClick: () => onNavigate && onNavigate(l),
    onMouseEnter: () => setHov(l),
    onMouseLeave: () => setHov(null),
    style: {
      cursor: 'pointer',
      fontFamily: tec ? 'var(--font-tecnica)' : 'var(--font-texto)',
      fontSize: tec ? 14 : 17,
      color: current === l || hov === l ? 'var(--nk-hueso)' : 'var(--nk-gris-texto)',
      transition: 'color var(--dur-fast)'
    }
  }, l))), /*#__PURE__*/React.createElement("div", {
    style: {
      justifySelf: 'end'
    }
  }, tec ? /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "outlineAccent",
    shape: "square",
    size: "sm",
    arrow: true,
    onClick: onCta
  }, cta || 'Contactar') : /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "md",
    onClick: onCta
  }, cta || 'Agenda una reunión'))));
}
Object.assign(__ds_scope, { NavBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavBar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/LandingBase.jsx
try { (() => {
const LB_LOGO = '../../assets/logo/';
function LandingBase({
  go
}) {
  const {
    NavBar,
    Footer,
    Button,
    Eyebrow,
    ChartPanel,
    ServiceCard,
    StepItem
  } = window.NniklabDesignSystem_cf651b;
  const wrap = {
    maxWidth: 1264,
    margin: '0 auto',
    padding: '0 24px',
    boxSizing: 'border-box'
  };
  const h2 = {
    fontFamily: 'var(--font-titulos)',
    fontWeight: 700,
    fontSize: 52,
    lineHeight: 1.15,
    letterSpacing: '-1.5px',
    margin: '20px 0 0'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--nk-grafito)',
      color: 'var(--nk-hueso)'
    }
  }, /*#__PURE__*/React.createElement(NavBar, {
    logoBasePath: LB_LOGO,
    onNavigate: go,
    onCta: () => go('Contacto')
  }), /*#__PURE__*/React.createElement("section", {
    style: {
      ...wrap,
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) minmax(0,560px)',
      gap: 64,
      alignItems: 'center',
      padding: '120px 24px 96px'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "AI, Data & Automation"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-titulos)',
      fontWeight: 700,
      fontSize: 84,
      lineHeight: 1.02,
      letterSpacing: '-4px',
      margin: '18px 0 0'
    }
  }, "Tus datos,", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--nk-lima)'
    }
  }, "trabajando"), /*#__PURE__*/React.createElement("br", null), "por ti."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 20,
      lineHeight: 1.65,
      color: 'var(--nk-gris-texto)',
      maxWidth: 500,
      margin: '48px 0 0'
    }
  }, "Ordenamos tu informaci\xF3n, automatizamos tus procesos e incorporamos IA para que tu negocio decida mejor y trabaje menos."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 16,
      marginTop: 48
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    onClick: () => go('Contacto')
  }, "Hablemos de tu proyecto"), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    variant: "secondary",
    onClick: () => go('Servicios')
  }, "Ver servicios"))), /*#__PURE__*/React.createElement(ChartPanel, null)), /*#__PURE__*/React.createElement("section", {
    id: "Servicios",
    style: {
      ...wrap,
      padding: '40px 24px 120px'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Servicios"), /*#__PURE__*/React.createElement("h2", {
    style: h2
  }, "Soluciones que convierten", /*#__PURE__*/React.createElement("br", null), "informaci\xF3n en ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--nk-lima)'
    }
  }, "resultados"), "."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,minmax(0,1fr))',
      gap: 24,
      marginTop: 56
    }
  }, /*#__PURE__*/React.createElement(ServiceCard, {
    index: "01",
    title: "Datos",
    description: "An\xE1lisis, ingenier\xEDa y arquitectura de datos para que tu informaci\xF3n sea confiable y \xFAtil."
  }), /*#__PURE__*/React.createElement(ServiceCard, {
    index: "02",
    title: "Automatizaci\xF3n",
    description: "Conectamos tus aplicaciones y eliminamos tareas repetitivas con flujos que trabajan solos."
  }), /*#__PURE__*/React.createElement(ServiceCard, {
    index: "03",
    title: "Inteligencia artificial",
    description: "Incorporamos IA en tus procesos para clasificar, analizar y responder m\xE1s r\xE1pido."
  }))), /*#__PURE__*/React.createElement("section", {
    id: "C\xF3mo trabajamos",
    style: {
      background: 'var(--nk-hueso)',
      color: 'var(--nk-grafito)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      padding: '112px 24px 120px'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    onLight: true
  }, "C\xF3mo trabajamos"), /*#__PURE__*/React.createElement("h2", {
    style: h2
  }, "Un proceso claro, de principio a fin."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,minmax(0,1fr))',
      gap: 32,
      marginTop: 64
    }
  }, /*#__PURE__*/React.createElement(StepItem, {
    step: "Paso 1",
    title: "Diagn\xF3stico",
    description: "Entendemos tu negocio y tus datos.",
    active: true
  }), /*#__PURE__*/React.createElement(StepItem, {
    step: "Paso 2",
    title: "Dise\xF1o",
    description: "Definimos la soluci\xF3n a tu medida."
  }), /*#__PURE__*/React.createElement(StepItem, {
    step: "Paso 3",
    title: "Implementaci\xF3n",
    description: "Construimos, probamos y entregamos."
  }), /*#__PURE__*/React.createElement(StepItem, {
    step: "Paso 4",
    title: "Acompa\xF1amiento",
    description: "Medimos resultados y mejoramos."
  })))), /*#__PURE__*/React.createElement("section", {
    id: "Contacto",
    style: {
      background: 'var(--nk-lima)',
      color: 'var(--nk-grafito)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      padding: '100px 24px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      ...h2,
      margin: 0,
      fontSize: 56,
      lineHeight: 1.05,
      letterSpacing: '-2px'
    }
  }, "\xBFListo para que tus datos", /*#__PURE__*/React.createElement("br", null), "trabajen por ti?"), /*#__PURE__*/React.createElement(Button, {
    variant: "dark",
    size: "lg",
    href: "mailto:nniklab@outlook.com"
  }, "Agenda una reuni\xF3n"))), /*#__PURE__*/React.createElement(Footer, {
    logoBasePath: LB_LOGO
  }));
}
window.LandingBase = LandingBase;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/LandingBase.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/LandingTecnico.jsx
try { (() => {
const LT_LOGO = '../../assets/logo/';
function LandingTecnico({
  go
}) {
  const {
    NavBar,
    Footer,
    Button,
    Eyebrow,
    PipelineStep,
    PipelineArrow,
    ServiceRow
  } = window.NniklabDesignSystem_cf651b;
  const wrap = {
    maxWidth: 1264,
    margin: '0 auto',
    padding: '0 24px',
    boxSizing: 'border-box'
  };
  const grid = {
    backgroundImage: 'linear-gradient(var(--grid-line) 1px,transparent 1px),linear-gradient(90deg,var(--grid-line) 1px,transparent 1px)',
    backgroundSize: '72px 72px'
  };
  const head = (t, c, size) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-titulos)',
      fontWeight: 700,
      fontSize: size,
      letterSpacing: size > 50 ? '-2px' : '-1.5px',
      lineHeight: 1.1,
      margin: 0
    }
  }, t), /*#__PURE__*/React.createElement(Eyebrow, {
    kind: "comment"
  }, c));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--nk-grafito)',
      color: 'var(--nk-hueso)'
    }
  }, /*#__PURE__*/React.createElement(NavBar, {
    style: "tecnico",
    logoBasePath: LT_LOGO,
    onNavigate: go,
    onCta: () => go('/contacto')
  }), /*#__PURE__*/React.createElement("section", {
    style: {
      ...grid,
      borderBottom: '1px solid var(--nk-linea)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      padding: '96px 24px 110px'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    kind: "prompt",
    cursor: true
  }, "ai_data_automation"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-titulos)',
      fontWeight: 700,
      fontSize: 112,
      lineHeight: 1.02,
      letterSpacing: '-6px',
      margin: '24px 0 0'
    }
  }, "Del dato crudo", /*#__PURE__*/React.createElement("br", null), "a la ", /*#__PURE__*/React.createElement("span", {
    style: {
      background: 'var(--nk-lima)',
      color: 'var(--nk-grafito)',
      padding: '0 18px'
    }
  }, "decisi\xF3n.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      gap: 32,
      marginTop: 56
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 20,
      lineHeight: 1.65,
      color: 'var(--nk-gris-texto)',
      maxWidth: 520,
      margin: 0
    }
  }, "Construimos la infraestructura de datos, las automatizaciones y la IA que tu negocio necesita para operar con precisi\xF3n."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Button, {
    shape: "square",
    size: "lg",
    onClick: () => go('/contacto'),
    style: {
      height: 62
    }
  }, "Agenda una reuni\xF3n"), /*#__PURE__*/React.createElement(Button, {
    shape: "square",
    variant: "secondary",
    size: "lg",
    onClick: () => go('/servicios'),
    style: {
      height: 62
    }
  }, "Ver servicios"))))), /*#__PURE__*/React.createElement("section", {
    id: "/proceso",
    style: {
      background: 'var(--nk-superficie)',
      borderBottom: '1px solid var(--nk-linea)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      padding: '100px 24px 100px'
    }
  }, head(/*#__PURE__*/React.createElement(React.Fragment, null, "As\xED fluyen tus datos con nniklab"), 'pipeline', 46), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      marginTop: 44
    }
  }, /*#__PURE__*/React.createElement(PipelineStep, {
    index: "01",
    tag: "fuentes",
    title: "ERP, Excel, CRM"
  }), /*#__PURE__*/React.createElement(PipelineArrow, null), /*#__PURE__*/React.createElement(PipelineStep, {
    index: "02",
    tag: "pipeline",
    title: "Limpieza e integraci\xF3n"
  }), /*#__PURE__*/React.createElement(PipelineArrow, null), /*#__PURE__*/React.createElement(PipelineStep, {
    index: "03",
    tag: "inteligencia",
    title: "Modelos e IA"
  }), /*#__PURE__*/React.createElement(PipelineArrow, null), /*#__PURE__*/React.createElement(PipelineStep, {
    index: "04",
    tag: "resultado",
    title: "Decisiones",
    active: true
  })))), /*#__PURE__*/React.createElement("section", {
    id: "/servicios",
    style: {
      ...wrap,
      padding: '120px 24px 100px'
    }
  }, head('Servicios', '05 soluciones', 60), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--nk-linea)',
      marginTop: 44
    }
  }, /*#__PURE__*/React.createElement(ServiceRow, {
    index: "01",
    title: "An\xE1lisis de datos",
    description: "Dashboards, reportes e indicadores para decidir con claridad."
  }), /*#__PURE__*/React.createElement(ServiceRow, {
    index: "02",
    title: "Ingenier\xEDa de datos",
    description: "Pipelines que integran, limpian y mueven tu informaci\xF3n de forma confiable."
  }), /*#__PURE__*/React.createElement(ServiceRow, {
    index: "03",
    title: "Arquitectura de datos",
    description: "Dise\xF1amos la base para que tus datos crezcan contigo."
  }), /*#__PURE__*/React.createElement(ServiceRow, {
    index: "04",
    title: "Automatizaci\xF3n",
    description: "Flujos que conectan tus aplicaciones y eliminan tareas repetitivas."
  }), /*#__PURE__*/React.createElement(ServiceRow, {
    index: "05",
    title: "Inteligencia artificial",
    description: "IA aplicada a tus procesos: clasificar, extraer, responder."
  }))), /*#__PURE__*/React.createElement("section", {
    id: "/contacto",
    style: {
      ...wrap,
      padding: '30px 24px 110px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...grid,
      border: '1px solid var(--nk-lima-line)',
      padding: '72px 72px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, {
    kind: "prompt"
  }, "siguiente_paso"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-titulos)',
      fontWeight: 700,
      fontSize: 64,
      letterSpacing: '-3px',
      lineHeight: 1.05,
      marginTop: 14
    }
  }, "Hablemos de tus datos.")), /*#__PURE__*/React.createElement(Button, {
    shape: "square",
    size: "lg",
    arrow: true,
    href: "mailto:nniklab@outlook.com",
    style: {
      height: 72,
      padding: '0 40px',
      fontSize: 20
    }
  }, "Agenda una reuni\xF3n"))), /*#__PURE__*/React.createElement(Footer, {
    style: "tecnico",
    logoBasePath: LT_LOGO
  }));
}
window.LandingTecnico = LandingTecnico;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/LandingTecnico.jsx", error: String((e && e.message) || e) }); }

__ds_ns.ChartPanel = __ds_scope.ChartPanel;

__ds_ns.PipelineStep = __ds_scope.PipelineStep;

__ds_ns.PipelineArrow = __ds_scope.PipelineArrow;

__ds_ns.ServiceCard = __ds_scope.ServiceCard;

__ds_ns.StatTile = __ds_scope.StatTile;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.ServiceRow = __ds_scope.ServiceRow;

__ds_ns.StepItem = __ds_scope.StepItem;

__ds_ns.Footer = __ds_scope.Footer;

__ds_ns.NavBar = __ds_scope.NavBar;

})();
