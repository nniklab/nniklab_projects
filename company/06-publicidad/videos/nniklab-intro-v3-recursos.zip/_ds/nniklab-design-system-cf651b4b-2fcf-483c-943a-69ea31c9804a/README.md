# nniklab Design System

**nniklab — AI, Data & Automation.** nniklab builds data and automation solutions for businesses of any size, with AI used across both lines:
- **Datos:** análisis, ingeniería y arquitectura de datos.
- **Automatización:** integración de aplicaciones y flujos de trabajo automáticos.
- **IA:** clasificar y extraer información de documentos, generar análisis y reportes, atender consultas, tomar decisiones dentro de procesos.

Contacto oficial: Juan Heredia T. · +593 99 578 4113 · nniklab@outlook.com

The brand is young (identity approved 2026-10-10). The only "product" surface so far is the **company landing page**, present in source as two static mockups with provisional copy. There is no production code.

## Sources
- GitHub: https://github.com/nniklab/nniklab_projects (branch `main`) — `company/` (lowercase since 2026-10-11) holds brand guides (`01-marca/colores`, `01-marca/tipografia`, `01-marca/logo`), verbal identity (`03-comunicacion/identidad-verbal.md`), web mockups (`05-web/`), advertising (`06-publicidad/`: intro video v2, music, brand graphics, photo backgrounds) and a backup orange palette (`99-respaldo/`, not in use). Explore this repo further when designing — new decisions (services catalogue, slogan, business card) will land there.
- Reference images copied to `assets/reference/`: official palette, typography sheet, logo presentation, both landing mockups.

## Index
- `styles.css` — entry point (imports only) → `tokens/fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `base.css`
- `guidelines/` — 20 foundation specimen cards (Colors, Type, Spacing, Brand, Imagery)
- `components/` — React primitives (see below)
- `ui_kits/web/` — landing page recreation (Base + Técnico)
- `assets/graficos/` — 4 brand graphics, 1920×1080, fictitious data — use the PNGs; SVGs are editable sources (their text needs the fonts installed)
- `assets/fondos/` — 3 licensed photo backgrounds (Pexels/Unsplash License)
- `assets/logo/` — all official SVG logos + icon PNG; `assets/favicon.ico`; `assets/reference/`
- `SKILL.md`, `github.md`, `thumbnail.html`

## Components
No component library exists in source; this set is extracted from the two landing mockups (every visible UI element, nothing more).
- **core/**: Button, IconButton, Badge, Eyebrow, Logo
- **cards/**: ServiceCard, StatTile, ChartPanel, PipelineStep (+ PipelineArrow)
- **lists/**: ServiceRow, StepItem
- **navigation/**: NavBar, Footer

Intentional additions: **Logo** (wraps the official SVG files so nobody retypes the wordmark); Button `disabled` state and Badge `solid`/`neutral` tones (not shown in mockups; minimal extensions).

## UI kits
- `ui_kits/web/index.html` — Landing nniklab. Two visual styles from source, toggle bottom-right: **Base** (pill buttons, rounded cards) and **Técnico** (square buttons, grid, mono labels). Don't mix the two in one page.

---

## CONTENT FUNDAMENTALS
- **Language:** Spanish everywhere. The only English is the descriptor **"AI, Data & Automation"** — written exactly so ("AI" first, comma, "&").
- **Name:** always **nniklab**, lowercase, even at sentence start. Never "NnikLab", "NNIKLAB".
- **Address:** informal *tú* ("Tus datos, trabajando por ti", "para que tu negocio decida mejor"). The company speaks as *nosotros* in verbs ("Ordenamos", "Construimos", "Incorporamos").
- **Casing:** sentence case for headings and buttons. Caps only in short mono/eyebrow labels ("SERVICIOS", "AI, DATA & AUTOMATION").
- **Tone:** clear, practical, outcome-first; short declarative headlines ending in a period ("Un proceso claro, de principio a fin."). Value = less work, better decisions. No hype, no jargon in headlines; technical words live in mono labels.
- **CTAs:** verb-first and conversational — "Agenda una reunión", "Hablemos de tu proyecto", "Ver servicios", "Contactar →".
- **Técnico flavour:** code-like micro-labels — `> ai_data_automation`, `// pipeline`, `/servicios`, `01 · fuentes`, snake_case.
- **Highlight:** one word per headline gets lima ("trabajando", "resultados", "decisión.").
- **Slogan:** not yet chosen; "Datos que trabajan. Procesos que fluyen." is in provisional use (closing of intro video v2). Candidates: "Datos que trabajan. Procesos que fluyen." · "Del dato a la decisión." · "Tus datos, trabajando por ti." · "Datos claros, decisiones seguras."
- **Emoji:** never. Numbers as two-digit indices (01, 02…).

## VISUAL FOUNDATIONS
- **Color:** Grafito `#111418` base (60%), superficies `#1A1D22`/línea `#2E333B` (20%), Blanco hueso `#F4F4F2` (10%), Lima eléctrico `#C6F432` accent (10%, sparingly). Gris texto `#9CA3AF` for secondary copy on dark; Gris acero `#6B7280` secondary on light (large text only); Lima oscuro `#5E7A0E` is the accent on light backgrounds. **Never lima on white/hueso** (1,2:1). Blue palettes were rejected on purpose.
- **Type:** Space Grotesk (titles, 400/500/700, negative tracking ≥30px), Inter (body, buttons, 400/500/600), JetBrains Mono (labels, data; never paragraphs). Max two weights per piece plus regular. No decorative italics, no long caps.
- **Backgrounds:** flat colour fields. Dark by default; full-bleed hueso band for process; full-bleed lima band for the closing CTA (Base). Técnico adds a faint 72px line grid (`rgba(255,255,255,.035)`). No gradients or textures on the website; photographic backgrounds are used in advertising/video.
- **Imagery:** two kinds, from `06-publicidad/imagenes/`. (1) Own graphics: flat dashboards, flows and app-integration diagrams in the official palette and fonts, lima as accent. (2) Dark stock photos (particles, connected cubes, green circuit) — cool, near-black, with green/lime light; darken 40–60 % behind text. No recognisable people or visible third-party logos. Recolour any illustration/icon to the palette.
- **Cards:** `#1A1D22` fill, 1px `#2E333B` border, radius 20 (service cards) / 24 (hero panel) / 12 (inset tiles) / 10 (técnico pipeline). No shadows — depth comes from the surface step and the 1px line.
- **Shadows/effects:** none. The logo rules forbid shadows and effects; extended to the UI. No blur, no transparency except the lima tint behind badges.
- **Borders:** 1px línea for cards, rows, nav rule; 3px top rule on process steps (lima oscuro for the active one).
- **Radii:** pill (999) for Base buttons/badges/icon buttons; 0 for Técnico buttons and CTA frame.
- **Layout:** 1264px content width (~96px side margins at 1440), 88px header with bottom rule, ~120px section padding, 24px card gutters. Hero is two columns (text + data panel).
- **Hover:** lima fills brighten slightly (`#D4FA5C`); outlines go from línea to acero; icon buttons fill lima; row titles turn lima. **Press:** 1px downward nudge. *(Interaction states are not specified in source — these are conservative inferences.)*
- **Animation:** none specified; keep to quick 120–200ms colour/border transitions, no bounces.
- **Mobile scale:** H1 40, H2 30, H3 22, body 16.

## ICONOGRAPHY
- Source contains **no icon set, icon font or SVG icons**. The mockups use only Unicode arrows: **→** (CTAs, pipeline) and **↗** (service rows, in a 48px circular outline).
- Brand marks live in `assets/logo/`: wordmark (oscuro/claro/mono-blanco/mono-negro — on lima use mono-negro; the separate lima file was removed upstream on 2026-10-11), descriptor variants, and the reduced **"ni"** icon (default, redondo, cuadrado, lima, claro) + `nniklab-icono-ni-512.png`, `assets/favicon.ico`.
- The lima square (the dot of the i) is the brand motif; it also appears as a terminal cursor block in Técnico labels. It is **always square**.
- The source recommends **Lucide or Phosphor** if icons are needed (open source), recoloured with the palette. Not yet used anywhere.
- No emoji.

## Fonts
All three families are Google Fonts (SIL OFL), loaded via `tokens/fonts.css`. No font binaries exist in the source repo, so no local `@font-face` files are shipped.
