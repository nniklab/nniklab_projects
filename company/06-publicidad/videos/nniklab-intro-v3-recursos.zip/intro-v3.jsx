// nniklab · Intro v3 "Del caos al orden" — 1080×1920, música Minimal Technology
const W = 1080, H = 1920;
const C = { lima: '#C6F432', grafito: '#111418', sup: '#1A1D22', linea: '#2E333B', hueso: '#F4F4F2', gris: '#9CA3AF', acero: '#6B7280', limaOsc: '#5E7A0E', tint: 'rgba(198,244,50,.12)' };
const F = { title: "'Space Grotesk', sans-serif", text: "'Inter', sans-serif", mono: "'JetBrains Mono', monospace" };
const AUDIO_OFFSET = 7.74; // el "drop" de la pista (13,74 s) cae en el corte a Datos (6,0 s)

// ── tres helpers de movimiento: progreso 0..1 entre a y b ──
const prog = (T, a, b) => clamp((T - a) / (b - a), 0, 1);
const MOTION = {
  enter: (T, a, b) => Easing.easeOutCubic(prog(T, a, b)),
  draw: (T, a, b) => Easing.easeInOutCubic(prog(T, a, b)),
  pop: (T, a, b) => Easing.easeOutBack(prog(T, a, b)),
};
const mix = (a, b, p) => a + (b - a) * p;
const fmt = (n) => Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '\u2009');

// Visibilidad de escena: entra subiendo, sale subiendo
function vis(T, a, b, noEnter) {
  const i = noEnter ? 1 : MOTION.enter(T, a - 0.1, a + 0.45);
  const o = MOTION.draw(T, b - 0.4, b + 0.02);
  return { op: Math.min(i, 1 - o), y: (1 - i) * 90 - o * 90 };
}

const abs = (s) => Object.assign({ position: 'absolute' }, s);
const mono = (size, color, extra) => Object.assign({ fontFamily: F.mono, fontSize: size, color: color || C.gris, letterSpacing: 3, textTransform: 'uppercase', whiteSpace: 'nowrap' }, extra);

// ── Fondos fotográficos ──
function Backgrounds({ T, CUES, photos }) {
  const layers = [
    { src: 'assets/fondos/particulas-oscuras.jpg', op: Math.max(1 - MOTION.draw(T, CUES.Datos - 0.2, CUES.Datos), MOTION.enter(T, CUES.Cierre - 0.3, CUES.Cierre + 0.6)), z: 1.08 + T * 0.006 },
    { src: 'assets/fondos/cubos-conectados.jpg', op: Math.min(MOTION.enter(T, CUES.Datos - 0.2, CUES.Datos), 1 - MOTION.draw(T, CUES.Automatizacion - 0.4, CUES.Automatizacion + 0.2)), z: 1.05 + (T - CUES.Datos) * 0.012 },
    { src: 'assets/fondos/circuito-verde.jpg', op: Math.min(MOTION.enter(T, CUES.Automatizacion - 0.4, CUES.Automatizacion + 0.2), 1 - MOTION.draw(T, CUES.Integracion - 0.3, CUES.Integracion + 0.1)), z: 1.04 + (T - CUES.Automatizacion) * 0.02 },
  ];
  return (
    <div style={abs({ inset: 0, background: C.grafito, overflow: 'hidden' })}>
      {photos && layers.map((l, i) => (
        <img key={i} src={l.src} style={abs({ inset: 0, width: W, height: H, objectFit: 'cover', opacity: l.op, transform: `scale(${l.z})` })} />
      ))}
      <div style={abs({ inset: 0, background: C.grafito, opacity: 0.58 })} />
    </div>
  );
}

// ── Titulares: uno visible a la vez ──
const HEADS = (CU) => [
  { at: 0.35, to: CU.Caos + 1.9, text: 'Datos por todas partes.' },
  { at: CU.Caos + 1.9, to: CU.Punto - 0.05, text: 'Tareas hechas a mano.' },
  { at: CU.Punto + 0.45, to: CU.Punto + 2.15, pre: 'Pongamos ', hi: 'orden.' },
  { at: CU.Datos + 0.35, to: CU.IA, eb: '01 · Datos', pre: 'Tus datos, por fin ', hi: 'claros.' },
  { at: CU.IA + 0.1, to: CU.Automatizacion, eb: '02 · IA', pre: 'La IA ', hi: 'lee', post: ' tus documentos.' },
  { at: CU.Automatizacion + 0.1, to: CU.Integracion, eb: '03 · Automatización', pre: 'Procesos que ', hi: 'fluyen', post: ' solos.' },
  { at: CU.Integracion + 0.2, to: CU.Cierre, eb: '04 · Integración', pre: 'Todas tus apps, ', hi: 'conectadas.' },
];
function Headline({ T, CUES }) {
  const h = HEADS(CUES).find((x) => T >= x.at && T < x.to);
  if (!h) return null;
  const i = MOTION.enter(T, h.at, h.at + 0.5), o = MOTION.draw(T, h.to - 0.3, h.to);
  return (
    <div style={abs({ left: 96, top: 210, width: 900, opacity: Math.min(i, 1 - o), transform: `translateY(${(1 - i) * 50 - o * 30}px)` })}>
      {h.eb && <div style={mono(26, C.lima, { letterSpacing: 4, marginBottom: 26 })}>{h.eb}</div>}
      <div style={{ fontFamily: F.title, fontWeight: 500, fontSize: 92, lineHeight: 1.04, letterSpacing: -2.5, color: C.hueso, textWrap: 'balance' }}>
        {h.pre || h.text}{h.hi && <span style={{ color: C.lima }}>{h.hi}</span>}{h.post}
      </div>
    </div>
  );
}

function MiniHeader({ T, CUES }) {
  const op = Math.min(MOTION.enter(T, CUES.Datos + 0.3, CUES.Datos + 0.8), 1 - MOTION.draw(T, CUES.Integracion - 0.35, CUES.Integracion) + MOTION.enter(T, CUES.Integracion + 1.0, CUES.Integracion + 1.4), 1 - MOTION.draw(T, CUES.Cierre - 0.4, CUES.Cierre));
  return (
    <div style={abs({ left: 96, right: 96, top: 92, height: 44, display: 'flex', alignItems: 'center', justifyContent: 'space-between', opacity: op })}>
      <img src="assets/logo/logo-oscuro.svg" style={{ height: 40 }} />
      <span style={mono(20, C.gris, { letterSpacing: 2 })}>AI, Data &amp; Automation</span>
    </div>
  );
}

// ── 1 · Caos ──
const CHAOS = [
  { x: 300, y: 760, r: -8, s: 1.1, k: 'CORREO', v: '48 sin leer' },
  { x: 770, y: 680, r: 6, s: 1.0, k: 'reporte_final_v7.xlsx', v: 'Versión 7 de 7', grid: true },
  { x: 650, y: 1010, r: -4, s: 1.2, k: 'PEDIDO #1042', v: 'Pendiente' },
  { x: 290, y: 1190, r: 10, s: 1.0, k: 'FACTURA', v: 'Sin registrar', paper: true },
  { x: 800, y: 1340, r: -7, s: 1.15, k: 'TIEMPO POR PEDIDO', v: '15 min' },
  { x: 360, y: 1530, r: 5, s: 1.05, k: 'INVENTARIO', v: 'Actualizar a mano' },
  { x: 780, y: 1650, r: -11, s: 0.95, k: 'COPIAR · PEGAR', v: '× 37 veces' },
  { x: 220, y: 950, r: 13, s: 0.9, k: 'HOJA 3', v: '#¡REF!' },
];
function ChaosCard({ c, i, T, CUES }) {
  const born = 0.15 + i * 0.3;
  const pIn = MOTION.pop(T, born, born + 0.4);
  const shake = MOTION.enter(T, 1.2, CUES.Punto) * (1 - MOTION.enter(T, CUES.Punto, CUES.Punto + 0.15));
  const order = MOTION.draw(T, CUES.Punto + 0.4 + i * 0.07, CUES.Punto + 1.2 + i * 0.07);
  const gx = i % 2 ? 780 : 300, gy = 760 + Math.floor(i / 2) * 200;
  const dx = Math.sin(T * 1.3 + i * 1.7) * 16 + Math.sin(T * 37 + i) * 7 * shake;
  const dy = Math.cos(T * 1.1 + i) * 12 + Math.cos(T * 41 + i * 2) * 6 * shake;
  const x = mix(c.x + dx, gx, order), y = mix(c.y + dy, gy, order);
  const rot = mix(c.r + Math.sin(T * 29 + i) * 2 * shake, 0, order);
  const sc = mix(c.s, 1, order) * pIn;
  const paper = c.paper;
  return (
    <div style={abs({ left: x - 200, top: y - 80, width: 400, height: 160, boxSizing: 'border-box', padding: '26px 30px', borderRadius: 20,
      background: paper ? C.hueso : C.sup, border: `1px solid ${paper ? C.hueso : C.linea}`, transform: `rotate(${rot}deg) scale(${sc})`,
      opacity: Math.min(1, pIn) * (1 - order * 0.35), display: 'flex', flexDirection: 'column', justifyContent: 'space-between' })}>
      <div style={mono(20, paper ? C.acero : C.gris, { letterSpacing: c.k === c.k.toUpperCase() ? 3 : 0, textTransform: 'none' })}>{c.k}</div>
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
        <div style={{ fontFamily: F.title, fontWeight: 500, fontSize: 44, letterSpacing: -1, color: paper ? C.grafito : C.hueso }}>{c.v}</div>
        {c.grid && <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,18px)', gap: 4 }}>
          {Array.from({ length: 8 }).map((_, j) => <div key={j} style={{ height: 12, background: j === 5 ? C.acero : C.linea }} />)}
        </div>}
      </div>
    </div>
  );
}
function Chaos({ T, CUES }) {
  return (
    <Shot from={0} to={CUES.Datos + 0.05}>
      {CHAOS.map((c, i) => <ChaosCard key={i} c={c} i={i} T={T} CUES={CUES} />)}
    </Shot>
  );
}

// ── 2 · Datos (dashboard reconstruido) ──
const SERIES = [0.08, 0.24, 0.19, 0.36, 0.32, 0.46, 0.42, 0.58, 0.53, 0.72, 0.86, 1.0];
const CH = { x0: 152, x1: 928, y0: 1440, h: 200 };
const chartPt = (i, v) => [CH.x0 + (i / 11) * (CH.x1 - CH.x0), CH.y0 - v * CH.h];
function chartTip(p) {
  const f = p * 11, i = Math.min(10, Math.floor(f)), r = f - i;
  const a = chartPt(i, SERIES[i]), b = chartPt(i + 1, SERIES[i + 1]);
  return [mix(a[0], b[0], r), mix(a[1], b[1], r)];
}
const DRAW = (CU) => [CU.Datos + 0.6, CU.Datos + 2.3];
function Kpi({ label, value, badge, big, style }) {
  return (
    <div style={abs(Object.assign({ boxSizing: 'border-box', background: C.grafito, border: `1px solid ${C.linea}`, borderRadius: 12, padding: '28px 32px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }, style))}>
      <div style={mono(19)}>{label}</div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ fontFamily: F.title, fontWeight: 700, fontSize: big ? 118 : 70, letterSpacing: big ? -4 : -2, lineHeight: 1, color: C.hueso }}>{value}</div>
        <div style={{ fontFamily: F.mono, fontSize: 24, color: C.lima, background: C.tint, borderRadius: 999, padding: '10px 20px' }}>{badge}</div>
      </div>
    </div>
  );
}
function Datos({ T, CUES }) {
  const v = vis(T, CUES.Datos, CUES.IA, true);
  const [d0, d1] = DRAW(CUES);
  const pd = MOTION.draw(T, d0, d1);
  const cnt = MOTION.enter(T, CUES.Datos + 0.4, CUES.Datos + 1.8);
  const pts = SERIES.map((s, i) => chartPt(i, s));
  const line = 'M' + pts.map((p) => p.join(' ')).join(' L');
  const area = line + ` L${CH.x1} ${CH.y0} L${CH.x0} ${CH.y0} Z`;
  const tip = chartTip(pd);
  const bars = [['Tienda online', 42], ['Redes sociales', 27], ['Local físico', 19], ['Mayoristas', 12]];
  return (
    <Shot from={CUES.Datos - 0.1} to={CUES.IA + 0.1}>
      <div style={abs({ inset: 0, opacity: v.op, transform: `translateY(${v.y}px)` })}>
        <div style={abs({ left: 72, top: 600, width: 936, height: 1100, boxSizing: 'border-box', background: C.sup, border: `1px solid ${C.linea}`, borderRadius: 24 })} />
        <div style={abs({ left: 112, right: 112, top: 600, height: 84, display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: `1px solid ${C.linea}` })}>
          <span style={mono(20)}>Panel · Ventas</span>
          <span style={mono(19, C.gris, { textTransform: 'none', letterSpacing: 1, display: 'flex', alignItems: 'center', gap: 12 })}><span style={{ width: 12, height: 12, background: C.lima }} />actualizado hace 2 min</span>
        </div>
        <Kpi big label="Ingresos del mes" value={'$' + fmt(48250 * cnt)} badge="▲ 18 %" style={{ left: 112, top: 716, width: 856, height: 214 }} />
        <Kpi label="Pedidos procesados" value={fmt(1240 * cnt)} badge="▲ 9 %" style={{ left: 112, top: 954, width: 416, height: 170 }} />
        <Kpi label="Horas ahorradas" value={Math.round(32 * cnt) + ' h'} badge="▲ 6 h" style={{ left: 552, top: 954, width: 416, height: 170 }} />
        <div style={abs({ left: 112, top: 1148, width: 856, height: 340, boxSizing: 'border-box', background: C.grafito, border: `1px solid ${C.linea}`, borderRadius: 12 })} />
        <div style={abs({ left: 144, top: 1176, fontFamily: F.text, fontSize: 26, color: C.hueso })}>Ingresos · últimos 12 meses</div>
        <svg width={W} height={H} style={abs({ left: 0, top: 0, overflow: 'visible' })}>
          {[0, 1, 2].map((g) => <line key={g} x1={CH.x0} x2={CH.x1} y1={CH.y0 - g * 100} y2={CH.y0 - g * 100} stroke={C.linea} strokeWidth="1" />)}
          <clipPath id="v3area"><rect x={CH.x0} y={1200} width={(CH.x1 - CH.x0) * pd} height={260} /></clipPath>
          <path d={area} fill={C.tint} clipPath="url(#v3area)" />
          <path d={line} fill="none" stroke={C.lima} strokeWidth="5" strokeLinejoin="round" pathLength="1" strokeDasharray="1" strokeDashoffset={1 - pd} />
        </svg>
        <div style={abs({ left: tip[0] - 220, top: tip[1] - 92, width: 180, height: 56, borderRadius: 10, background: C.sup, border: `1px solid ${C.linea}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: F.mono, fontSize: 24, color: C.hueso, opacity: MOTION.enter(T, d1 - 0.1, d1 + 0.3) })}>$48 250</div>
        <div style={abs({ left: 144, right: 144, top: 1516, display: 'flex', flexDirection: 'column', gap: 18 })}>
          {bars.map(([n, pc], i) => {
            const pb = MOTION.enter(T, CUES.Datos + 1.3 + i * 0.15, CUES.Datos + 2.2 + i * 0.15);
            return (
              <div key={n} style={{ display: 'grid', gridTemplateColumns: '230px 1fr 70px', alignItems: 'center', gap: 20 }}>
                <span style={{ fontFamily: F.text, fontSize: 22, color: C.hueso }}>{n}</span>
                <div style={{ height: 10, borderRadius: 999, background: C.linea }}><div style={{ height: 10, borderRadius: 999, width: `${(pc / 42) * 100 * pb}%`, background: i === 0 ? C.lima : C.acero }} /></div>
                <span style={{ fontFamily: F.mono, fontSize: 20, color: C.gris, textAlign: 'right' }}>{Math.round(pc * pb)} %</span>
              </div>
            );
          })}
        </div>
      </div>
    </Shot>
  );
}

// ── 3 · IA (factura → datos extraídos) ──
const SCAN = (CU) => [CU.IA + 0.5, CU.IA + 1.4];
const FAC = { x: 160, y: 590, w: 760, h: 500 };
function IA({ T, CUES }) {
  const v = vis(T, CUES.IA, CUES.Automatizacion);
  const [s0, s1] = SCAN(CUES);
  const ps = MOTION.draw(T, s0, s1);
  const scanY = FAC.y + 24 + ps * (FAC.h - 48);
  const hl = (y) => MOTION.enter(T, s0 + ((y - FAC.y) / FAC.h) * (s1 - s0), s0 + ((y - FAC.y) / FAC.h) * (s1 - s0) + 0.2);
  const node = MOTION.pop(T, CUES.IA + 1.6, CUES.IA + 1.95);
  const fields = [['Proveedor', 'Distribuidora Andina S.A.'], ['RUC', '0190123456001'], ['Fecha', '08/10/2026'], ['Total', '$1 284,60']];
  const typed = (s, i) => s.slice(0, Math.round(s.length * MOTION.enter(T, CUES.IA + 1.95 + i * 0.14, CUES.IA + 2.35 + i * 0.14)));
  const press = MOTION.pop(T, CUES.IA + 2.55, CUES.IA + 2.75);
  const sent = T > CUES.IA + 2.65;
  const box = (x, y, w, h) => {
    const p = hl(FAC.y + y);
    return <div style={abs({ left: x, top: y, width: w, height: h, boxSizing: 'border-box', borderRadius: 10, border: `3px solid rgba(94,122,14,${p})`, background: `rgba(94,122,14,${0.1 * p})` })} />;
  };
  const bar = (x, y, w, c) => <div style={abs({ left: x, top: y, width: w, height: 12, borderRadius: 6, background: c || '#D3D5D0' })} />;
  return (
    <Shot from={CUES.IA - 0.2} to={CUES.Automatizacion + 0.1}>
      <div style={abs({ inset: 0, opacity: v.op, transform: `translateY(${v.y}px)` })}>
        <div style={abs({ left: FAC.x, top: FAC.y, width: FAC.w, height: FAC.h, borderRadius: 20, background: C.hueso, overflow: 'hidden' })}>
          <div style={abs({ left: 48, top: 40, fontFamily: F.title, fontWeight: 700, fontSize: 52, letterSpacing: -1, color: C.grafito })}>FACTURA</div>
          <div style={abs({ left: 48, top: 104, fontFamily: F.mono, fontSize: 20, color: C.acero })}>N.° 001-002-000458</div>
          {box(36, 150, 400, 96)}{bar(56, 170, 300, '#A9B0A0')}{bar(56, 194, 240)}{bar(56, 218, 220)}
          {box(460, 150, 264, 96)}{bar(480, 172, 200, '#A9B0A0')}{bar(530, 200, 150)}
          {[278, 312, 346, 380].map((y, i) => <React.Fragment key={y}>{bar(56, y, [260, 200, 300, 180][i])}{bar(560, y, 140)}</React.Fragment>)}
          {box(36, 414, 688, 66)}
          <div style={abs({ left: 60, top: 432, fontFamily: F.mono, fontSize: 22, color: C.grafito, letterSpacing: 2 })}>TOTAL</div>
          <div style={abs({ right: 60, top: 424, fontFamily: F.title, fontWeight: 700, fontSize: 38, color: C.grafito })}>$1 284,60</div>
          <div style={abs({ left: 0, right: 0, top: scanY - FAC.y - 2, height: 4, background: C.limaOsc, opacity: ps > 0 && ps < 1 ? 1 : 0 })} />
        </div>
        <div style={abs({ left: 539, top: FAC.y + FAC.h, width: 2, height: 1148 - (FAC.y + FAC.h), background: C.linea })} />
        <div style={abs({ left: 465, top: 1148, width: 150, height: 150, boxSizing: 'border-box', borderRadius: 30, border: `3px solid ${C.lima}`, background: C.grafito, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${0.9 + 0.1 * node})`, fontFamily: F.title, fontWeight: 700, fontSize: 64, color: C.lima })}>IA</div>
        <div style={abs({ left: 650, top: 1170, display: 'flex', flexDirection: 'column', gap: 10 })}>
          {['lee', 'extrae', 'clasifica'].map((w, i) => <span key={w} style={mono(20, T > CUES.IA + 1.7 + i * 0.12 ? C.hueso : C.acero, { textTransform: 'none', letterSpacing: 1 })}>{'0' + (i + 1) + ' · ' + w}</span>)}
        </div>
        <div style={abs({ left: 539, top: 1298, width: 2, height: 42, background: C.linea })} />
        <div style={abs({ left: 72, top: 1340, width: 936, height: 380, boxSizing: 'border-box', borderRadius: 20, background: C.sup, border: `1px solid ${C.linea}`, padding: '0 40px' })}>
          <div style={{ height: 76, display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: `1px solid ${C.linea}` }}>
            <span style={mono(20)}>Datos extraídos</span>
            <span style={{ fontFamily: F.mono, fontSize: 22, color: C.lima, background: C.tint, borderRadius: 999, padding: '8px 18px', opacity: MOTION.enter(T, CUES.IA + 2.3, CUES.IA + 2.5) }}>✓ 98 %</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', rowGap: 22, columnGap: 28, padding: '24px 0' }}>
            {fields.map(([k, val], i) => (
              <div key={k} style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                <span style={mono(17, C.acero)}>{k}</span>
                <span style={{ fontFamily: F.text, fontSize: 28, color: C.hueso, height: 36, whiteSpace: 'nowrap' }}>{typed(val, i)}</span>
              </div>
            ))}
          </div>
          <div style={{ height: 66, borderRadius: 999, background: sent ? C.lima : C.grafito, border: `1px solid ${sent ? C.lima : C.linea}`, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, fontFamily: F.text, fontWeight: 600, fontSize: 26, color: sent ? C.grafito : C.gris, transform: `translateY(${press > 0 && press < 1 ? 1 : 0}px)` }}>
            {sent ? 'Enviado a contabilidad →' : 'Enviar a contabilidad'}
          </div>
        </div>
      </div>
    </Shot>
  );
}

// ── 4 · Automatización (flujo de un pedido) ──
const STEPS = [
  ['01 · Disparador', 'Nuevo pedido', 'Tienda online'],
  ['02 · Validación', 'Validar datos', 'Stock y pago'],
  ['03 · IA', 'Clasificar pedido', 'Prioridad'],
  ['04 · Acción', 'Actualizar inventario', 'ERP'],
  ['05 · Acción', 'Avisar al cliente', 'Correo'],
];
const RAIL_X = 132;
const stepY = (k) => 600 + k * 142 + 56;
const stepAt = (CU, k) => CU.Automatizacion + 0.45 + k * 0.3;
function Automatizacion({ T, CUES }) {
  const v = vis(T, CUES.Automatizacion, CUES.Integracion);
  const t0 = stepAt(CUES, 0), t4 = stepAt(CUES, 4);
  const fill = MOTION.draw(T, t0, t4);
  const cd = MOTION.enter(T, t4 + 0.15, t4 + 0.85);
  const secs = Math.round(mix(900, 20, cd));
  return (
    <Shot from={CUES.Automatizacion - 0.2} to={CUES.Integracion + 0.1}>
      <div style={abs({ inset: 0, opacity: v.op, transform: `translateY(${v.y}px)` })}>
        <div style={abs({ left: RAIL_X - 1, top: stepY(0), width: 2, height: stepY(4) - stepY(0), background: C.linea })} />
        <div style={abs({ left: RAIL_X - 1, top: stepY(0), width: 2, height: (stepY(4) - stepY(0)) * fill, background: C.lima })} />
        {STEPS.map(([lab, title, sub], k) => {
          const on = MOTION.pop(T, stepAt(CUES, k), stepAt(CUES, k) + 0.3);
          const ai = k === 2;
          return (
            <div key={k} style={abs({ left: 190, top: 600 + k * 142, width: 818, height: 112, boxSizing: 'border-box', borderRadius: 20, background: C.sup,
              border: `${ai && on > 0 ? 2 : 1}px solid ${ai && on > 0 ? C.lima : C.linea}`, padding: '0 28px', display: 'flex', alignItems: 'center', gap: 24, transform: `translateX(${(1 - Math.min(on, 1)) * 0 + (on > 0 && on < 1 ? 6 * Math.sin(on * Math.PI) : 0)}px)` })}>
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 6 }}>
                <span style={mono(17, ai ? C.lima : C.gris)}>{lab}</span>
                <span style={{ fontFamily: F.title, fontWeight: 500, fontSize: 34, letterSpacing: -0.5, color: C.hueso }}>{title}</span>
              </div>
              <span style={{ fontFamily: F.text, fontSize: 22, color: C.gris, whiteSpace: 'nowrap' }}>{sub}</span>
              <div style={{ width: 38, height: 38, boxSizing: 'border-box', border: `1px solid ${on > 0 ? C.lima : C.linea}`, background: on > 0 ? C.lima : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: F.text, fontWeight: 600, fontSize: 22, color: C.grafito, transform: `scale(${on > 0 ? on : 1})` }}>{on > 0 ? '✓' : ''}</div>
            </div>
          );
        })}
        <div style={abs({ left: 72, top: 1340, width: 936, height: 300, boxSizing: 'border-box', borderRadius: 24, background: C.sup, border: `1px solid ${C.linea}`, padding: '36px 44px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' })}>
          <span style={mono(20)}>Tiempo por pedido</span>
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <span style={{ fontFamily: F.mono, fontSize: 20, color: C.acero }}>antes</span>
              <span style={{ position: 'relative', fontFamily: F.title, fontWeight: 500, fontSize: 64, color: C.acero }}>15 min
                <span style={abs({ left: -4, top: '52%', height: 4, width: `${104 * cd}%`, background: C.gris })} />
              </span>
            </div>
            <span style={{ fontFamily: F.title, fontSize: 56, color: C.gris, marginBottom: 14 }}>→</span>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'flex-end' }}>
              <span style={{ fontFamily: F.mono, fontSize: 20, color: C.lima }}>ahora</span>
              <span style={{ fontFamily: F.title, fontWeight: 700, fontSize: 116, lineHeight: 0.9, letterSpacing: -4, color: C.lima, opacity: MOTION.enter(T, t4, t4 + 0.15) }}>{secs} s</span>
            </div>
          </div>
        </div>
      </div>
    </Shot>
  );
}

// ── 5 · Integración (PNG con zoom desde el ícono "ni") ──
const NI = { x: 999, y: 504, size: 22 }, NI_SCREEN = { x: 540, y: 1060 };
const niScale = (T, CU) => mix(3.2, 0.74, MOTION.draw(T, CU.Integracion + 0.05, CU.Integracion + 1.5)) - 0.06 * MOTION.enter(T, CU.Integracion + 1.5, CU.Cierre + 0.6);
function Integracion({ T, CUES }) {
  const s = niScale(T, CUES);
  const op = Math.min(MOTION.enter(T, CUES.Integracion - 0.25, CUES.Integracion + 0.1), 1 - MOTION.draw(T, CUES.Cierre - 0.3, CUES.Cierre + 0.2));
  return (
    <Shot from={CUES.Integracion - 0.3} to={CUES.Cierre + 0.3}>
      <img src="assets/graficos/integracion-apps.png" style={abs({ left: NI_SCREEN.x - NI.x * s, top: NI_SCREEN.y - NI.y * s, width: 1920 * s, height: 1080 * s, opacity: op, maxWidth: 'none' })} />
    </Shot>
  );
}

// ── 6 · Cierre ──
const LOGO = { x: 160, y: 790, w: 760 };
const LOGO_K = LOGO.w / 660.8;
const LOGO_DOT = { x: LOGO.x + 257 * LOGO_K, y: LOGO.y + 17 * LOGO_K, size: 34 * LOGO_K };
function Cierre({ T, CUES }) {
  const land = CUES.Cierre + 0.5;
  const rev = MOTION.enter(T, land + 0.05, land + 0.75);
  const sl = MOTION.enter(T, land + 0.8, land + 1.3);
  const ct = MOTION.enter(T, land + 1.3, land + 1.8);
  return (
    <Shot from={CUES.Cierre - 0.1} to={999}>
      <img src="assets/logo/logo-descriptor-oscuro-sin-punto.svg" style={abs({ left: LOGO.x, top: LOGO.y, width: LOGO.w, clipPath: `inset(0 ${(1 - rev) * 100}% 0 0)`, transform: `translateX(${(1 - rev) * -20}px)` })} />
      <div style={abs({ left: 96, right: 96, top: 1170, textAlign: 'center', fontFamily: F.title, fontWeight: 500, fontSize: 74, lineHeight: 1.1, letterSpacing: -2, color: C.hueso, opacity: sl, transform: `translateY(${(1 - sl) * 40}px)` })}>
        Datos que <span style={{ color: C.lima }}>trabajan.</span><br />Procesos que fluyen.
      </div>
      <div style={abs({ left: 0, right: 0, top: 1560, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14, opacity: ct, transform: `translateY(${(1 - ct) * 30}px)` })}>
        <span style={{ fontFamily: F.mono, fontSize: 30, color: C.hueso }}>+593 99 578 4113</span>
        <span style={{ fontFamily: F.mono, fontSize: 30, color: C.gris }}>nniklab@outlook.com</span>
      </div>
    </Shot>
  );
}

// ── El protagonista: el cuadrado lima (el punto de la i) ──
function dotState(T, CU) {
  const center = { x: 540, y: 1160 };
  // Punto: aparece, ordena, crece hasta cubrir la pantalla
  if (T < CU.Datos) {
    const pIn = MOTION.pop(T, CU.Punto, CU.Punto + 0.45);
    const grow = MOTION.draw(T, CU.Datos - 0.7, CU.Datos);
    const pulse = 1 + 0.12 * Math.sin(Math.max(0, T - CU.Punto) * 9) * (1 - grow);
    return { ...center, size: mix(56 * pIn * pulse, 2700, grow), op: T < CU.Punto ? 0 : 1 };
  }
  const [d0, d1] = DRAW(CU);
  if (T < CU.IA - 0.35) {
    const shr = MOTION.enter(T, CU.Datos, CU.Datos + 0.6);
    const tip = chartTip(MOTION.draw(T, d0, d1));
    const sz = mix(2700, 24, shr);
    return { x: mix(center.x, tip[0], shr), y: mix(center.y, tip[1], shr), size: sz + (T > d1 ? 4 * Math.sin((T - d1) * 10) : 0) };
  }
  const [s0, s1] = SCAN(CU);
  const iaV = vis(T, CU.IA, CU.Automatizacion);
  if (T < s1) {
    const from = chartTip(1), fly = MOTION.draw(T, CU.IA - 0.35, s0);
    const ps = MOTION.draw(T, s0, s1);
    const sy = FAC.y + 24 + ps * (FAC.h - 48) + iaV.y;
    return { x: mix(from[0], FAC.x - 34, fly), y: mix(from[1] - 90, sy, fly), size: 26 };
  }
  if (T < CU.IA + 2.45) {
    const toNode = MOTION.draw(T, s1, CU.IA + 1.7);
    const sy = FAC.y + FAC.h - 24;
    const atNode = { x: 540, y: 1223 };
    const toBtn = MOTION.draw(T, CU.IA + 2.15, CU.IA + 2.45);
    const btn = { x: 760, y: 1340 + 314 };
    const x = mix(mix(FAC.x - 34, atNode.x, toNode), btn.x, toBtn);
    const y = mix(mix(sy, atNode.y, toNode), btn.y, toBtn);
    return { x, y: y + iaV.y, size: mix(26, 40, toNode * (1 - toBtn)) + (toNode >= 1 && toBtn <= 0 ? 4 * Math.sin((T - CU.IA - 1.7) * 12) : 0) };
  }
  const t0 = stepAt(CU, 0), t4 = stepAt(CU, 4);
  const auV = vis(T, CU.Automatizacion, CU.Integracion);
  if (T < t0) {
    const fly = MOTION.draw(T, CU.IA + 2.6, t0);
    return { x: mix(760, RAIL_X, fly), y: mix(1654 + iaV.y, stepY(0) + auV.y, fly), size: mix(26, 22, fly), op: T < CU.IA + 2.75 ? 1 : 1 };
  }
  if (T < CU.Integracion - 0.35) {
    const f = MOTION.draw(T, t0, t4);
    return { x: RAIL_X, y: mix(stepY(0), stepY(4), f) + auV.y, size: 22 };
  }
  if (T < CU.Cierre) {
    const fly = MOTION.draw(T, CU.Integracion - 0.35, CU.Integracion + 0.05);
    const s = niScale(T, CU);
    return { x: mix(RAIL_X, NI_SCREEN.x, fly), y: mix(stepY(4) + auV.y, NI_SCREEN.y, fly), size: mix(22, NI.size * s, fly) };
  }
  const land = CU.Cierre + 0.5;
  const fly = MOTION.draw(T, CU.Cierre - 0.05, land);
  const s = niScale(T, CU);
  const pop = MOTION.pop(T, land, land + 0.35);
  return { x: mix(NI_SCREEN.x, LOGO_DOT.x, fly), y: mix(NI_SCREEN.y, LOGO_DOT.y, fly), size: T < land ? mix(NI.size * s, LOGO_DOT.size * 1.6, fly) : mix(LOGO_DOT.size * 1.6, LOGO_DOT.size, pop) };
}
function Dot({ T, CUES }) {
  const d = dotState(T, CUES);
  return <div style={abs({ left: d.x - d.size / 2, top: d.y - d.size / 2, width: d.size, height: d.size, background: C.lima, opacity: d.op == null ? 1 : d.op })} />;
}

// ── Música ──
function Music({ time, playing, muted }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const v = ref.current;
    if (!v) return;
    v.muted = !!muted;
    const target = AUDIO_OFFSET + time;
    if (playing) {
      if (Math.abs(v.currentTime - target) > 0.3) v.currentTime = target;
      if (v.paused) v.play().catch(() => {});
    } else {
      if (!v.paused) v.pause();
      if (Math.abs(v.currentTime - target) > 0.05) v.currentTime = target;
    }
  });
  return <video ref={ref} src="assets/audio/minimal-technology.mp3" preload="auto" playsInline
    data-om-exportable-video-play-start={AUDIO_OFFSET} data-om-exportable-video-play-end={AUDIO_OFFSET + 23}
    style={abs({ left: 0, top: 0, width: 2, height: 2, opacity: 0, pointerEvents: 'none' })} />;
}

function Piece({ tw }) {
  const { T, CUES, time, playing } = useComposition();
  return (
    <div data-screen-label={`t=${Math.floor(time)}s`} style={abs({ inset: 0, overflow: 'hidden', background: C.grafito })}>
      <Backgrounds T={T} CUES={CUES} photos={tw.photos} />
      <Chaos T={T} CUES={CUES} />
      <Datos T={T} CUES={CUES} />
      <IA T={T} CUES={CUES} />
      <Automatizacion T={T} CUES={CUES} />
      <Integracion T={T} CUES={CUES} />
      <Cierre T={T} CUES={CUES} />
      <MiniHeader T={T} CUES={CUES} />
      <Headline T={T} CUES={CUES} />
      <Dot T={T} CUES={CUES} />
      <Music time={time} playing={playing} muted={!tw.music} />
    </div>
  );
}

function IntroV3() {
  const [tw, setTweak] = useTweaks(window.TWEAK_DEFAULTS || { motionEditor: true, music: true, photos: true });
  return (
    <div style={{ position: 'fixed', inset: 0, background: '#0b0b0e' }}>
      <CompositionStage width={W} height={H} bg={C.grafito} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK}>
        <Piece tw={tw} />
      </CompositionStage>
      <TweaksPanel>
        <TweakSection label="Video" />
        <TweakToggle label="Motion editor" value={tw.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
        <TweakToggle label="Música en la vista previa" value={tw.music} onChange={(v) => setTweak('music', v)} />
        <TweakToggle label="Fondos fotográficos" value={tw.photos} onChange={(v) => setTweak('photos', v)} />
      </TweaksPanel>
    </div>
  );
}
window.IntroV3 = IntroV3;
