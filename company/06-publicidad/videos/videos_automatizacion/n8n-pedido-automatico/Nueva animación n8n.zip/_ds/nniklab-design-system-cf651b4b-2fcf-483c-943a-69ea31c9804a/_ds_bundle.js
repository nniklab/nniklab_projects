/* @ds-bundle: {"format":4,"namespace":"NniklabDesignSystem_cf651b","components":[{"name":"ExampleCard","sourcePath":"components/cards/ExampleCard.jsx"},{"name":"FlowCard","sourcePath":"components/cards/FlowCard.jsx"},{"name":"FloatPanel","sourcePath":"components/cards/ProblemCard.jsx"},{"name":"ProblemCard","sourcePath":"components/cards/ProblemCard.jsx"},{"name":"ProcessStep","sourcePath":"components/cards/ProcessStep.jsx"},{"name":"ServiceCard","sourcePath":"components/cards/ServiceCard.jsx"},{"name":"TechCard","sourcePath":"components/cards/TechCard.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Chip","sourcePath":"components/core/Chip.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"Logo","sourcePath":"components/core/Logo.jsx"},{"name":"SectionLabel","sourcePath":"components/core/SectionLabel.jsx"},{"name":"TextLink","sourcePath":"components/core/TextLink.jsx"},{"name":"SectionHeader","sourcePath":"components/layout/SectionHeader.jsx"},{"name":"Section","sourcePath":"components/layout/SectionHeader.jsx"},{"name":"CarouselControls","sourcePath":"components/navigation/CarouselControls.jsx"},{"name":"Footer","sourcePath":"components/navigation/Footer.jsx"},{"name":"NavBar","sourcePath":"components/navigation/NavBar.jsx"}],"sourceHashes":{"components/cards/ExampleCard.jsx":"906a945dcac4","components/cards/FlowCard.jsx":"6e189166ef53","components/cards/ProblemCard.jsx":"e56e38ab63ff","components/cards/ProcessStep.jsx":"01cd1ee100cb","components/cards/ServiceCard.jsx":"6a43129b71db","components/cards/TechCard.jsx":"4eb8ef6f2e88","components/core/Button.jsx":"d3b0c9f9e432","components/core/Chip.jsx":"2198759991f5","components/core/Icon.jsx":"b365749ba65f","components/core/Logo.jsx":"66f3fc9451f6","components/core/SectionLabel.jsx":"8677fe9a54d2","components/core/TextLink.jsx":"a22cd7add54f","components/layout/SectionHeader.jsx":"843881ab24c0","components/navigation/CarouselControls.jsx":"c0e32c719bf4","components/navigation/Footer.jsx":"17a29031bbc2","components/navigation/NavBar.jsx":"6e526ae48b03","ui_kits/web/Hero.jsx":"32f983218480","ui_kits/web/Sections.jsx":"bad3d4f1f7b6"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.NniklabDesignSystem_cf651b = window.NniklabDesignSystem_cf651b || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/cards/ExampleCard.jsx
try { (() => {
function ExampleCard({
  tag,
  title,
  text
}) {
  const [h, setH] = React.useState(false);
  return /*#__PURE__*/React.createElement("article", {
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      background: '#111418',
      border: '1px solid ' + (h ? '#c6f432' : '#2e333b'),
      borderRadius: 8,
      padding: 24,
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      transform: h ? 'translateY(-4px)' : 'none',
      transition: 'border-color .25s ease, transform .25s ease',
      color: '#f4f4f2',
      fontFamily: "'Inter', Arial, sans-serif",
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'JetBrains Mono', Consolas, monospace",
      fontSize: 12,
      letterSpacing: '1px',
      color: '#c6f432'
    }
  }, tag), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: "'Space Grotesk', Arial, sans-serif",
      fontSize: 22,
      fontWeight: 500,
      lineHeight: 1.2
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: '#9ca3af',
      fontSize: 16,
      lineHeight: 1.6
    }
  }, text));
}
Object.assign(__ds_scope, { ExampleCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/ExampleCard.jsx", error: String((e && e.message) || e) }); }

// components/cards/FlowCard.jsx
try { (() => {
function FlowCard({
  tag,
  title,
  steps = []
}) {
  const [h, setH] = React.useState(false);
  return /*#__PURE__*/React.createElement("article", {
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      background: '#111418',
      border: '1px solid #c6f432',
      borderRadius: 8,
      padding: 32,
      display: 'flex',
      flexDirection: 'column',
      gap: 24,
      transform: h ? 'translateY(-4px)' : 'none',
      transition: 'transform .25s ease',
      color: '#f4f4f2',
      fontFamily: "'Inter', Arial, sans-serif"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'JetBrains Mono', Consolas, monospace",
      fontSize: 12,
      letterSpacing: '1px',
      color: '#c6f432'
    }
  }, tag), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: "'Space Grotesk', Arial, sans-serif",
      fontSize: 26,
      fontWeight: 500,
      lineHeight: 1.2
    }
  }, title)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      alignItems: 'center',
      gap: 12,
      fontSize: 15
    }
  }, steps.map((s, i) => {
    const last = i === steps.length - 1;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: i
    }, /*#__PURE__*/React.createElement("span", {
      style: last ? {
        background: '#c6f432',
        color: '#111418',
        padding: '12px 16px',
        fontWeight: 600
      } : {
        border: '1px solid #2e333b',
        padding: '12px 16px',
        background: '#1a1d22'
      }
    }, s), !last && /*#__PURE__*/React.createElement("span", {
      "aria-hidden": "true",
      style: {
        color: '#c6f432'
      }
    }, "\u2192"));
  })));
}
Object.assign(__ds_scope, { FlowCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/FlowCard.jsx", error: String((e && e.message) || e) }); }

// components/cards/ProblemCard.jsx
try { (() => {
function FloatPanel({
  children,
  row = false,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'rgba(17, 20, 24, 0.9)',
      border: '1px solid #2e333b',
      borderRadius: 8,
      padding: 12,
      display: 'flex',
      flexDirection: row ? 'row' : 'column',
      alignItems: row ? 'center' : 'stretch',
      gap: row ? 12 : 8,
      backdropFilter: 'blur(6px)',
      WebkitBackdropFilter: 'blur(6px)',
      fontSize: 13,
      color: '#f4f4f2',
      ...style
    }
  }, children);
}
function ProblemCard({
  image,
  alt = '',
  index,
  label,
  text,
  children,
  delay = 0,
  minHeight = 460
}) {
  const [h, setH] = React.useState(false);
  return /*#__PURE__*/React.createElement("article", {
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      position: 'relative',
      minHeight,
      border: '1px solid ' + (h ? '#c6f432' : '#2e333b'),
      borderRadius: 8,
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'flex-end',
      background: '#111418',
      transform: h ? 'translateY(-4px)' : 'none',
      transition: 'border-color .25s ease, transform .25s ease',
      color: '#f4f4f2',
      fontFamily: "'Inter', Arial, sans-serif",
      minWidth: 0
    }
  }, image && /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: alt,
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      display: 'block'
    }
  }), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(to bottom, rgba(17, 20, 24, 0.25) 0%, rgba(17, 20, 24, 0.55) 45%, rgba(17, 20, 24, 0.97) 100%)'
    }
  }), children && /*#__PURE__*/React.createElement("div", {
    className: "nk-flota",
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      top: 20,
      left: 16,
      right: 16,
      animationDelay: delay + 's'
    }
  }, children), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      padding: 24,
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'baseline',
      fontFamily: "'JetBrains Mono', Consolas, monospace",
      fontSize: 12,
      letterSpacing: '1px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#c6f432'
    }
  }, index), /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#c9ced6'
    }
  }, label)), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 19,
      lineHeight: 1.45,
      fontWeight: 500
    }
  }, text)));
}
Object.assign(__ds_scope, { FloatPanel, ProblemCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/ProblemCard.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
const SIZES = {
  sm: {
    padding: '12px 20px',
    minHeight: 44,
    fontSize: 15
  },
  md: {
    padding: '16px 28px',
    minHeight: 52,
    fontSize: 16
  },
  lg: {
    padding: '20px 36px',
    minHeight: 60,
    fontSize: 18
  }
};
function Button({
  variant = 'primary',
  size = 'md',
  arrow = false,
  glow = false,
  href,
  onClick,
  children,
  style
}) {
  const [h, setH] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  let v;
  if (variant === 'secondary') v = {
    background: 'transparent',
    color: h ? '#c6f432' : '#f4f4f2',
    border: '1px solid ' + (h ? '#c6f432' : '#2e333b'),
    fontWeight: 500,
    borderRadius: 0,
    transition: 'border-color .2s ease, color .2s ease'
  };else if (variant === 'dark') v = {
    background: '#111418',
    color: '#f4f4f2',
    border: 0,
    fontWeight: 600,
    borderRadius: 4,
    padding: '12px 18px',
    minHeight: 0,
    fontSize: 15,
    transform: h ? 'translateX(3px)' : 'none',
    transition: 'transform .2s ease'
  };else v = {
    background: h ? '#d8ff52' : '#c6f432',
    color: '#111418',
    border: 0,
    fontWeight: 600,
    borderRadius: 0,
    transform: h ? 'translateY(-1px)' : 'none',
    transition: 'background-color .2s ease, transform .2s ease'
  };
  const Tag = href ? 'a' : 'button';
  return /*#__PURE__*/React.createElement(Tag, {
    href: href,
    onClick: onClick,
    type: href ? undefined : 'button',
    className: glow ? 'nk-brillo' : undefined,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      boxSizing: 'border-box',
      fontFamily: "'Inter', Arial, sans-serif",
      lineHeight: 1.2,
      textDecoration: 'none',
      cursor: 'pointer',
      whiteSpace: 'nowrap',
      ...s,
      ...v,
      ...style
    }
  }, children, arrow && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true"
  }, "\u2192"));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Chip.jsx
try { (() => {
function Chip({
  children,
  kind = 'tech',
  pulse = false
}) {
  if (kind === 'status') return /*#__PURE__*/React.createElement("span", {
    style: {
      background: '#1a1d22',
      border: '1px solid #2e333b',
      padding: '6px 10px',
      fontFamily: "'JetBrains Mono', Consolas, monospace",
      fontSize: 11,
      color: '#f4f4f2',
      display: 'inline-flex',
      gap: 8,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: pulse ? 'nk-latido' : undefined,
    style: {
      width: 7,
      height: 7,
      background: '#c6f432',
      display: 'inline-block'
    }
  }), children);
  if (kind === 'file') return /*#__PURE__*/React.createElement("span", {
    style: {
      flex: '0 0 auto',
      fontFamily: "'JetBrains Mono', Consolas, monospace",
      fontSize: 10,
      background: '#2e333b',
      color: '#f4f4f2',
      padding: '2px 6px'
    }
  }, children);
  return /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'JetBrains Mono', Consolas, monospace",
      fontSize: 13,
      color: '#f4f4f2',
      background: '#111418',
      border: '1px solid #2e333b',
      borderRadius: 4,
      padding: '6px 10px',
      display: 'inline-block'
    }
  }, children);
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Chip.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
// Line icons copied verbatim from the nniklab site (company/05-web/sitio/index.html)
const ICONS = {
  "datos": [40, 1.6, "<ellipse cx=\"20\" cy=\"9\" rx=\"13\" ry=\"4.5\"></ellipse><path d=\"M7 9v11c0 2.5 5.8 4.5 13 4.5s13-2 13-4.5V9\"></path><path d=\"M7 20v11c0 2.5 5.8 4.5 13 4.5s13-2 13-4.5V20\"></path>"],
  "automatizacion": [40, 1.6, "<rect x=\"3\" y=\"6\" width=\"10\" height=\"10\"></rect><rect x=\"27\" y=\"6\" width=\"10\" height=\"10\"></rect><rect x=\"15\" y=\"25\" width=\"10\" height=\"10\"></rect><path d=\"M13 11h14\"></path><path d=\"M32 16v5H20v4\"></path><path d=\"M8 16v5h12\"></path>"],
  "ia": [40, 1.6, "<circle cx=\"20\" cy=\"20\" r=\"5\"></circle><circle cx=\"6\" cy=\"8\" r=\"3\"></circle><circle cx=\"34\" cy=\"8\" r=\"3\"></circle><circle cx=\"6\" cy=\"32\" r=\"3\"></circle><circle cx=\"34\" cy=\"32\" r=\"3\"></circle><path d=\"M8.5 10l7.5 6.5M31.5 10L24 16.5M8.5 30l7.5-6.5M31.5 30L24 23.5\"></path>"],
  "nube": [40, 1.6, "<path d=\"M12 30h17.5a7 7 0 0 0 1.2-13.9A10 10 0 0 0 11.2 17 6.5 6.5 0 0 0 12 30z\"></path><path d=\"M15 24h10\"></path>"],
  "bases": [40, 1.6, "<rect x=\"7\" y=\"6\" width=\"26\" height=\"8\"></rect><rect x=\"7\" y=\"16\" width=\"26\" height=\"8\"></rect><rect x=\"7\" y=\"26\" width=\"26\" height=\"8\"></rect><path d=\"M12 10h1M12 20h1M12 30h1\"></path>"],
  "flujo": [40, 1.6, "<rect x=\"5\" y=\"6\" width=\"11\" height=\"11\"></rect><rect x=\"24\" y=\"23\" width=\"11\" height=\"11\"></rect><path d=\"M16 11.5h5a4 4 0 0 1 4 4V23\"></path><path d=\"M22 20l3 3 3-3\"></path>"],
  "chispa": [40, 1.6, "<path d=\"M20 5l2.8 8.4L31 16l-8.2 2.6L20 27l-2.8-8.4L9 16l8.2-2.6z\"></path><path d=\"M31 26l1.2 3.3L35 30.5l-2.8 1.2L31 35l-1.2-3.3L27 30.5l2.8-1.2z\"></path>"],
  "codigo": [40, 1.6, "<path d=\"M14 12l-8 8 8 8\"></path><path d=\"M26 12l8 8-8 8\"></path><path d=\"M23 8l-6 24\"></path>"],
  "mas": [40, 1.6, "<rect x=\"6\" y=\"6\" width=\"28\" height=\"28\"></rect><path d=\"M20 13v14M13 20h14\"></path>"],
  "diagnostico": [32, 1.8, "<circle cx=\"14\" cy=\"14\" r=\"9\"></circle><path d=\"M21 21l7 7\"></path><path d=\"M10 14h8M14 10v8\"></path>"],
  "diseno": [32, 1.8, "<rect x=\"4\" y=\"4\" width=\"24\" height=\"24\"></rect><path d=\"M4 12h24M12 12v16\"></path>"],
  "construccion": [32, 1.8, "<path d=\"M11 9l-7 7 7 7M21 9l7 7-7 7M18 6l-4 20\"></path>"],
  "acompanamiento": [32, 1.8, "<path d=\"M4 26l8-9 6 5 10-12\"></path><path d=\"M21 10h7v7\"></path>"],
  "documento": [18, 1.8, "<rect x=\"3\" y=\"2\" width=\"12\" height=\"14\"></rect><path d=\"M6 6h6M6 9h6M6 12h3\"></path>"],
  "flecha-izq": [20, 1.8, "<path d=\"M16 10H4M9 5l-5 5 5 5\"></path>"],
  "flecha-der": [20, 1.8, "<path d=\"M4 10h12M11 5l5 5-5 5\"></path>"]
};
function Icon({
  name = 'datos',
  size,
  color = 'currentColor',
  strokeWidth
}) {
  const d = ICONS[name] || ICONS.datos;
  const vb = d[0];
  return /*#__PURE__*/React.createElement("svg", {
    width: size || vb,
    height: size || vb,
    viewBox: '0 0 ' + vb + ' ' + vb,
    fill: "none",
    stroke: color,
    strokeWidth: strokeWidth || d[1],
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true",
    style: {
      display: 'block',
      flex: 'none'
    },
    dangerouslySetInnerHTML: {
      __html: d[2]
    }
  });
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/cards/ProcessStep.jsx
try { (() => {
function ProcessStep({
  number,
  icon = 'diagnostico',
  title,
  text,
  receives,
  final = false,
  rail = true,
  pulseDelay = 'nk-d1'
}) {
  const [h, setH] = React.useState(false);
  const fg = final ? '#f4f4f2' : '#111418',
    muted = final ? '#9ca3af' : '#4b5563',
    accent = final ? '#c6f432' : '#5e7a0e';
  return /*#__PURE__*/React.createElement("li", {
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      position: 'relative',
      listStyle: 'none',
      background: final ? '#111418' : '#ffffff',
      color: fg,
      border: '1px solid ' + (final ? '#111418' : h ? '#5e7a0e' : '#d9dbd6'),
      borderRadius: 8,
      padding: '28px 24px',
      display: 'flex',
      flexDirection: 'column',
      gap: 16,
      transform: h ? 'translateY(-4px)' : 'none',
      transition: 'border-color .25s ease, transform .25s ease',
      fontFamily: "'Inter', Arial, sans-serif",
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: final ? 'nk-latido' : undefined,
    style: {
      width: 14,
      height: 14,
      background: accent,
      flex: '0 0 auto'
    }
  }), !final && rail && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      flex: '1 1 auto',
      height: 2,
      background: '#d9dbd6',
      marginRight: -49
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: 'nk-pulso nk-pulso-oscuro ' + pulseDelay
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'end'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'Space Grotesk', Arial, sans-serif",
      fontSize: 56,
      fontWeight: 700,
      lineHeight: 1,
      letterSpacing: '-2px',
      color: final ? '#c6f432' : '#111418'
    }
  }, number), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    color: accent
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: "'Space Grotesk', Arial, sans-serif",
      fontSize: 24,
      fontWeight: 500,
      letterSpacing: '-0.5px',
      lineHeight: 1.2
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: muted,
      fontSize: 16,
      lineHeight: 1.6
    }
  }, text), receives && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      paddingTop: 16,
      borderTop: '1px solid ' + (final ? '#2e333b' : '#e3e4e0'),
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'JetBrains Mono', Consolas, monospace",
      fontSize: 12,
      letterSpacing: '1px',
      color: muted
    }
  }, "RECIBES"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      lineHeight: 1.6,
      color: fg
    }
  }, receives)));
}
Object.assign(__ds_scope, { ProcessStep });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/ProcessStep.jsx", error: String((e && e.message) || e) }); }

// components/cards/ServiceCard.jsx
try { (() => {
function ServiceCard({
  icon = 'datos',
  index,
  title,
  items = [],
  note,
  result
}) {
  const [h, setH] = React.useState(false);
  return /*#__PURE__*/React.createElement("article", {
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      background: '#1a1d22',
      border: '1px solid ' + (h ? '#c6f432' : '#2e333b'),
      borderRadius: 8,
      padding: 32,
      display: 'flex',
      flexDirection: 'column',
      gap: 24,
      transform: h ? 'translateY(-4px)' : 'none',
      transition: 'border-color .25s ease, transform .25s ease',
      color: '#f4f4f2',
      fontFamily: "'Inter', Arial, sans-serif",
      boxSizing: 'border-box',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    color: "#c6f432"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'JetBrains Mono', Consolas, monospace",
      fontSize: 13,
      color: '#9ca3af'
    }
  }, index)), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: "'Space Grotesk', Arial, sans-serif",
      fontWeight: 500,
      fontSize: 30,
      lineHeight: 1.2,
      letterSpacing: '-0.5px'
    }
  }, title), /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: 0,
      padding: 0,
      listStyle: 'none',
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      color: '#9ca3af',
      fontSize: 16,
      lineHeight: 1.6
    }
  }, items.map((t, i) => /*#__PURE__*/React.createElement("li", {
    key: i
  }, t))), note && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      lineHeight: 1.6,
      color: '#9ca3af',
      padding: 12,
      background: '#111418'
    }
  }, note), result && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      marginTop: 'auto',
      paddingTop: 16,
      borderTop: '1px solid #2e333b',
      fontSize: 16,
      lineHeight: 1.6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#c6f432'
    }
  }, "\u2192"), " ", result));
}
Object.assign(__ds_scope, { ServiceCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/ServiceCard.jsx", error: String((e && e.message) || e) }); }

// components/cards/TechCard.jsx
try { (() => {
function TechCard({
  icon = 'nube',
  index,
  title,
  text,
  tools = [],
  accent = false,
  cta = 'Conversemos',
  href,
  onCta
}) {
  const [h, setH] = React.useState(false);
  if (accent) return /*#__PURE__*/React.createElement("article", {
    style: {
      background: '#c6f432',
      color: '#111418',
      borderRadius: 8,
      padding: 28,
      display: 'flex',
      flexDirection: 'column',
      gap: 16,
      fontFamily: "'Inter', Arial, sans-serif",
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon === 'nube' ? 'mas' : icon,
    size: 36,
    color: "#111418"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'JetBrains Mono', Consolas, monospace",
      fontSize: 13
    }
  }, index)), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: "'Space Grotesk', Arial, sans-serif",
      fontWeight: 700,
      fontSize: 26,
      lineHeight: 1.2,
      letterSpacing: '-0.5px'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 15,
      lineHeight: 1.5,
      color: '#2e333b'
    }
  }, text), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      alignSelf: 'start'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "dark",
    arrow: true,
    href: href,
    onClick: onCta
  }, cta)));
  return /*#__PURE__*/React.createElement("article", {
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      background: '#1a1d22',
      border: '1px solid ' + (h ? '#c6f432' : '#2e333b'),
      borderRadius: 8,
      padding: 28,
      display: 'flex',
      flexDirection: 'column',
      gap: 16,
      transform: h ? 'translateY(-4px)' : 'none',
      transition: 'border-color .25s ease, transform .25s ease',
      color: '#f4f4f2',
      fontFamily: "'Inter', Arial, sans-serif",
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 36,
    color: "#c6f432"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'JetBrains Mono', Consolas, monospace",
      fontSize: 13,
      color: '#9ca3af'
    }
  }, index)), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: "'Space Grotesk', Arial, sans-serif",
      fontWeight: 500,
      fontSize: 26,
      lineHeight: 1.2,
      letterSpacing: '-0.5px'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: '#9ca3af',
      fontSize: 15,
      lineHeight: 1.5
    }
  }, text), /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: 'auto 0 0',
      padding: '8px 0 0',
      listStyle: 'none',
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8
    }
  }, tools.map(t => /*#__PURE__*/React.createElement("li", {
    key: t
  }, /*#__PURE__*/React.createElement(__ds_scope.Chip, null, t)))));
}
Object.assign(__ds_scope, { TechCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/TechCard.jsx", error: String((e && e.message) || e) }); }

// components/core/Logo.jsx
try { (() => {
const FILES = {
  oscuro: 'nniklab-logo-oscuro.svg',
  claro: 'nniklab-logo-claro.svg',
  lima: 'nniklab-logo-mono-negro.svg',
  monoBlanco: 'nniklab-logo-mono-blanco.svg',
  monoNegro: 'nniklab-logo-mono-negro.svg'
};
const DESC = {
  oscuro: 'nniklab-logo-descriptor-oscuro.svg',
  claro: 'nniklab-logo-descriptor-claro.svg',
  lima: 'nniklab-logo-descriptor-lima.svg'
};
const ICON = {
  oscuro: 'nniklab-icono-ni.svg',
  claro: 'nniklab-icono-ni-claro.svg',
  lima: 'nniklab-icono-ni-lima.svg',
  redondo: 'nniklab-icono-ni-redondo.svg',
  cuadrado: 'nniklab-icono-ni-cuadrado.svg'
};
function Logo({
  on = 'oscuro',
  type = 'wordmark',
  height = 26,
  basePath = 'assets/logo/'
}) {
  const map = type === 'icon' ? ICON : type === 'descriptor' ? DESC : FILES;
  const file = map[on] || Object.values(map)[0];
  return /*#__PURE__*/React.createElement("img", {
    src: basePath + file,
    alt: "nniklab",
    style: {
      height,
      width: 'auto',
      display: 'block'
    }
  });
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Logo.jsx", error: String((e && e.message) || e) }); }

// components/core/SectionLabel.jsx
try { (() => {
function SectionLabel({
  children,
  kind = 'path',
  onLight = false,
  boxed = false,
  cursor
}) {
  const color = onLight ? '#5e7a0e' : '#c6f432';
  if (kind === 'prompt') {
    const showCursor = cursor !== false;
    const box = boxed ? {
      background: '#1a1d22',
      border: '1px solid #2e333b',
      padding: '8px 14px'
    } : {};
    return /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'JetBrains Mono', Consolas, monospace",
        fontSize: 13,
        letterSpacing: '1px',
        color,
        alignSelf: boxed ? 'center' : 'auto',
        ...box
      }
    }, "> ", children, showCursor && /*#__PURE__*/React.createElement("span", {
      className: "nk-cursor",
      "aria-hidden": "true"
    }, "_"));
  }
  if (kind === 'tag') return /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'JetBrains Mono', Consolas, monospace",
      fontSize: 12,
      letterSpacing: '1px',
      color
    }
  }, children);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'JetBrains Mono', Consolas, monospace",
      fontSize: 16,
      letterSpacing: '1.5px',
      color
    }
  }, children);
}
Object.assign(__ds_scope, { SectionLabel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SectionLabel.jsx", error: String((e && e.message) || e) }); }

// components/core/TextLink.jsx
try { (() => {
function TextLink({
  children,
  href,
  glyph = '↗',
  mono = false,
  color = '#c6f432'
}) {
  const [h, setH] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: href,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      color: h ? '#d8ff52' : color,
      textDecoration: 'none',
      fontWeight: mono ? 400 : 500,
      fontFamily: mono ? "'JetBrains Mono', Consolas, monospace" : "'Inter', Arial, sans-serif",
      fontSize: mono ? 13 : undefined,
      display: 'inline-flex',
      gap: 8,
      alignItems: 'center'
    }
  }, children, glyph && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true"
  }, glyph));
}
Object.assign(__ds_scope, { TextLink });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/TextLink.jsx", error: String((e && e.message) || e) }); }

// components/layout/SectionHeader.jsx
try { (() => {
function SectionHeader({
  label,
  title,
  aside,
  onLight = false,
  asideSize = 16,
  maxWidth = 720
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      alignItems: 'end',
      justifyContent: 'space-between',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16,
      maxWidth
    }
  }, label && /*#__PURE__*/React.createElement(__ds_scope.SectionLabel, {
    onLight: onLight
  }, label), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: "'Space Grotesk', Arial, sans-serif",
      fontWeight: 700,
      fontSize: 'clamp(32px, 4vw, 44px)',
      lineHeight: 1.1,
      letterSpacing: '-1.5px',
      color: onLight ? '#111418' : '#f4f4f2',
      textWrap: 'balance'
    }
  }, title)), aside && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      maxWidth: 380,
      color: onLight ? '#4b5563' : '#9ca3af',
      fontSize: asideSize,
      lineHeight: 1.6,
      fontFamily: "'Inter', Arial, sans-serif"
    }
  }, aside));
}
function Section({
  id,
  children,
  tone = 'dark',
  border = true,
  style
}) {
  const bg = tone === 'alt' ? '#1a1d22' : tone === 'light' ? '#f4f4f2' : '#111418';
  return /*#__PURE__*/React.createElement("section", {
    id: id,
    style: {
      background: bg,
      color: tone === 'light' ? '#111418' : '#f4f4f2',
      borderBottom: border && tone !== 'light' ? '1px solid #2e333b' : 'none',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      padding: 'clamp(64px, 8vw, 96px) 24px',
      display: 'flex',
      flexDirection: 'column',
      gap: 48,
      boxSizing: 'border-box'
    }
  }, children));
}
Object.assign(__ds_scope, { SectionHeader, Section });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/SectionHeader.jsx", error: String((e && e.message) || e) }); }

// components/navigation/CarouselControls.jsx
try { (() => {
function CarouselControls({
  count = 4,
  active = 0,
  onChange,
  onLight = false,
  label = 'Carrusel'
}) {
  const acc = onLight ? '#5e7a0e' : '#c6f432',
    off = onLight ? '#c9ccc4' : '#2e333b';
  const [h, setH] = React.useState(null);
  const go = i => onChange && onChange((i + count) % count);
  const arrow = dir => /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": label + (dir < 0 ? ': anterior' : ': siguiente'),
    onClick: () => go(active + dir),
    onMouseEnter: () => setH(dir),
    onMouseLeave: () => setH(null),
    style: {
      width: 44,
      height: 44,
      flex: '0 0 44px',
      padding: 0,
      color: acc,
      background: 'transparent',
      border: '1px solid ' + (h === dir ? acc : off),
      borderRadius: 4,
      cursor: 'pointer',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'border-color .2s ease'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: dir < 0 ? 'flecha-izq' : 'flecha-der'
  }));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 8
    }
  }, arrow(-1), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'center',
      gap: 2
    }
  }, Array.from({
    length: count
  }).map((_, i) => /*#__PURE__*/React.createElement("button", {
    key: i,
    type: "button",
    "aria-label": label + ': ver ' + (i + 1) + ' de ' + count,
    onClick: () => go(i),
    style: {
      width: 28,
      height: 28,
      padding: 0,
      border: 0,
      background: 'transparent',
      cursor: 'pointer',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      width: i === active ? 28 : 8,
      height: 8,
      background: i === active ? acc : off,
      transition: 'width .3s ease'
    }
  })))), arrow(1));
}
Object.assign(__ds_scope, { CarouselControls });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/CarouselControls.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Footer.jsx
try { (() => {
function Footer({
  phone = '+593 99 578 4113',
  email = 'nniklab@outlook.com',
  disclaimer = 'Los nombres y logos de terceros son marcas registradas de sus respectivos propietarios. Su uso no implica asociación ni respaldo.',
  logoBasePath = 'assets/logo/'
}) {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      borderTop: '1px solid #2e333b',
      background: '#111418'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      padding: '48px 24px',
      display: 'flex',
      flexDirection: 'column',
      gap: 32,
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    type: "descriptor",
    height: 44,
    basePath: logoBasePath
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 24,
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.TextLink, {
    mono: true,
    glyph: "",
    color: "#f4f4f2",
    href: 'tel:' + phone.replace(/\s/g, '')
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14
    }
  }, phone)), /*#__PURE__*/React.createElement(__ds_scope.TextLink, {
    mono: true,
    glyph: "",
    color: "#f4f4f2",
    href: 'mailto:' + email
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14
    }
  }, email)))), disclaimer && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      paddingTop: 24,
      borderTop: '1px solid #2e333b',
      fontSize: 13,
      color: '#9ca3af',
      fontFamily: "'Inter', Arial, sans-serif"
    }
  }, disclaimer)));
}
Object.assign(__ds_scope, { Footer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Footer.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavBar.jsx
try { (() => {
const DEFAULT = [['servicios', 'Servicios'], ['que-puedes-lograr', 'Qué puedes lograr'], ['como-trabajamos', 'Cómo trabajamos'], ['tecnologias', 'Tecnologías'], ['equipo', 'Nuestro equipo']];
function NavBar({
  links = DEFAULT,
  cta = 'Agenda una reunión',
  onNavigate,
  onCta,
  logoBasePath = 'assets/logo/',
  sticky = true
}) {
  const [hov, setHov] = React.useState(null);
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: sticky ? 'sticky' : 'relative',
      top: 0,
      zIndex: 20,
      background: 'rgba(17, 20, 24, 0.86)',
      backdropFilter: 'blur(12px)',
      WebkitBackdropFilter: 'blur(12px)',
      borderBottom: '1px solid #2e333b'
    }
  }, /*#__PURE__*/React.createElement("nav", {
    "aria-label": "Principal",
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      padding: '16px 24px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 24,
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("a", {
    onClick: () => onNavigate && onNavigate(null),
    style: {
      display: 'flex',
      alignItems: 'center',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    height: 26,
    basePath: logoBasePath
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 32,
      fontSize: 15,
      fontFamily: "'Inter', Arial, sans-serif"
    }
  }, links.map(([id, l]) => /*#__PURE__*/React.createElement("a", {
    key: id,
    onClick: () => onNavigate && onNavigate(id),
    onMouseEnter: () => setHov(id),
    onMouseLeave: () => setHov(null),
    style: {
      cursor: 'pointer',
      color: hov === id ? '#f4f4f2' : '#9ca3af',
      textDecoration: 'none',
      transition: 'color .2s ease'
    }
  }, l))), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "sm",
    onClick: onCta
  }, cta)));
}
Object.assign(__ds_scope, { NavBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavBar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/Hero.jsx
try { (() => {
const MONO = "'JetBrains Mono', Consolas, monospace",
  SG = "'Space Grotesk', Arial, sans-serif";
const FLOW_ROWS = [[150, 8, -3.2, 90, 7, -5.7], [90, 9, -5.2, 120, 7, -.6], [180, 7, -1.7, 180, 7, -5.8], [90, 8, -5, 90, 11, -6.4], [90, 8, -.4, 120, 9, -3.8], [90, 11, -3.4, 120, 7, -4.1], [120, 9, -.9, 90, 11, -.7], [120, 10, -6.8, 180, 9, -4.2], [180, 9, -2.7, 120, 12, -9.4], [90, 11, -3.3, 180, 9, -6.6]];
function HeroFlows() {
  return /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    className: "nk-flujo-capa",
    style: {
      position: 'absolute',
      inset: 0,
      overflow: 'hidden',
      pointerEvents: 'none'
    }
  }, FLOW_ROWS.map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "nk-flujo-linea",
    style: {
      top: 10 + i * 9 + '%'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "nk-flujo-seg",
    style: {
      width: r[0],
      animationDuration: r[1] + 's',
      animationDelay: r[2] + 's'
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "nk-flujo-seg",
    style: {
      width: r[3],
      animationDuration: r[4] + 's',
      animationDelay: r[5] + 's'
    }
  }))));
}
function SceneHead({
  n,
  t,
  children
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      fontFamily: MONO,
      fontSize: 12,
      letterSpacing: '1px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#c6f432'
    }
  }, t), /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#9ca3af'
    }
  }, n, " / 03")), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: SG,
      fontSize: 28,
      fontWeight: 500,
      lineHeight: 1.2,
      letterSpacing: '-0.5px'
    }
  }, children));
}
const BARS = [['ene', 38], ['feb', 52], ['mar', 46], ['abr', 64], ['may', 72], ['jun', 100]];
function HeroVisual() {
  const {
    Chip
  } = window.NniklabDesignSystem_cf651b;
  const box = (t, l, d) => /*#__PURE__*/React.createElement("div", {
    className: "nk-aparece",
    style: {
      flex: '0 0 auto',
      width: 120,
      border: '1px solid #2e333b',
      background: '#111418',
      padding: '10px 12px',
      display: 'flex',
      flexDirection: 'column',
      gap: 4,
      animationDelay: d + 's'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: MONO,
      fontSize: 10,
      color: '#9ca3af'
    }
  }, t), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      fontWeight: 500
    }
  }, l));
  const ok = (t, d) => /*#__PURE__*/React.createElement("div", {
    className: "nk-aparece",
    style: {
      fontFamily: MONO,
      fontSize: 12,
      color: '#9ca3af',
      animationDelay: d + 's'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#c6f432'
    }
  }, "[ok]"), " ", t);
  const field = (k, v, d, big) => /*#__PURE__*/React.createElement("div", {
    className: "nk-aparece",
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2,
      animationDelay: d + 's'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: MONO,
      fontSize: 10,
      color: '#9ca3af'
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: SG,
      fontSize: big ? 26 : 20,
      fontWeight: 500,
      color: big ? '#c6f432' : '#f4f4f2'
    }
  }, v));
  const lines = [[70], [90, 8.6], [55], [80, 9.2], [65], [85], [45, 9.8], [60]];
  return /*#__PURE__*/React.createElement("div", {
    className: "nk-entra-3",
    role: "img",
    "aria-label": "Animaci\xF3n en tres escenas",
    style: {
      position: 'relative',
      display: 'flex',
      flexDirection: 'column',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      minHeight: 380
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "nk-escena",
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(SceneHead, {
    n: "01",
    t: "01 \xB7 datos"
  }, "Ordenamos tus datos para ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#c6f432'
    }
  }, "decidir"), " mejor."), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      flex: 1,
      minHeight: 220,
      display: 'flex',
      alignItems: 'flex-end',
      gap: 14,
      paddingTop: 32,
      borderBottom: '1px solid #2e333b'
    }
  }, BARS.map(([m, v], i) => /*#__PURE__*/React.createElement("div", {
    key: m,
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'flex-end',
      alignItems: 'stretch',
      gap: 8,
      height: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "nk-barra",
    style: {
      height: v + '%',
      background: i === 5 ? '#c6f432' : '#2e333b',
      animationDelay: 0.1 * (i + 1) + 's'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: MONO,
      fontSize: 10,
      color: '#9ca3af',
      textAlign: 'center'
    }
  }, m))), /*#__PURE__*/React.createElement("div", {
    className: "nk-aparece",
    style: {
      position: 'absolute',
      top: 0,
      right: 0,
      animationDelay: '1.2s'
    }
  }, /*#__PURE__*/React.createElement(Chip, {
    kind: "status",
    pulse: true
  }, "dashboard actualizado")))), /*#__PURE__*/React.createElement("div", {
    className: "nk-escena nk-esc-2",
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(SceneHead, {
    n: "02",
    t: "02 \xB7 automatizaci\xF3n"
  }, "Conectamos tus apps y ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#c6f432'
    }
  }, "automatizamos"), " el trabajo."), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      left: 60,
      right: 60,
      top: '50%',
      height: 1,
      background: '#2e333b'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "nk-recorre",
    style: {
      position: 'absolute',
      top: -5,
      left: 0,
      width: 10,
      height: 10,
      background: '#c6f432',
      transform: 'translateX(-50%)'
    }
  })), box('01 · entrada', 'Formulario', 4.0), box('02 · flujo', 'Validar', 4.6), box('03 · salida', 'Registrar', 5.2)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, ok('formulario_recibido', 4.7), ok('datos_validados', 5.4), ok('registro_creado', 6.1)))), /*#__PURE__*/React.createElement("div", {
    className: "nk-escena nk-esc-3",
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(SceneHead, {
    n: "03",
    t: "03 \xB7 ia"
  }, "Incorporamos ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#c6f432'
    }
  }, "IA"), " en cada decisi\xF3n."), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      gap: 24,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      flex: '0 0 46%',
      border: '1px solid #2e333b',
      background: '#1a1d22',
      padding: 16,
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: MONO,
      fontSize: 10,
      color: '#9ca3af'
    }
  }, "factura_0451.pdf"), lines.map(([w, d], i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      height: 6,
      width: w + '%',
      background: '#2e333b',
      position: 'relative'
    }
  }, d && /*#__PURE__*/React.createElement("div", {
    className: "nk-aparece",
    style: {
      position: 'absolute',
      inset: 0,
      background: '#c6f432',
      animationDelay: d + 's'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "nk-escanea",
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      top: 0,
      height: 2,
      background: '#c6f432',
      opacity: .8
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, field('tipo', 'Factura', 8.8), field('proveedor', 'Andes S.A.', 9.4), field('total', '$ 1.240,00', 10.0, true))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12
    }
  }, ['DATOS', 'AUTOMATIZACIÓN', 'IA'].map((l, i) => /*#__PURE__*/React.createElement("div", {
    key: l,
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 2,
      background: '#2e333b',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: 'nk-progreso nk-prog-' + (i + 1),
    style: {
      position: 'absolute',
      left: 0,
      top: 0,
      bottom: 0,
      width: i ? '0%' : '100%',
      background: '#c6f432'
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: MONO,
      fontSize: 11,
      color: '#9ca3af',
      letterSpacing: '1px'
    }
  }, l)))));
}
function Hero({
  go
}) {
  const {
    Button,
    SectionLabel
  } = window.NniklabDesignSystem_cf651b;
  const ref = React.useRef(null);
  const [pos, setPos] = React.useState(null);
  return /*#__PURE__*/React.createElement("section", {
    id: "inicio",
    ref: ref,
    onMouseMove: e => {
      const r = ref.current.getBoundingClientRect();
      setPos([e.clientX - r.left - 360, e.clientY - r.top - 360]);
    },
    onMouseLeave: () => setPos(null),
    style: {
      position: 'relative',
      overflow: 'hidden',
      borderBottom: '1px solid #2e333b',
      background: '#111418'
    }
  }, /*#__PURE__*/React.createElement(HeroFlows, null), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      left: 0,
      top: 0,
      width: 720,
      height: 720,
      pointerEvents: 'none',
      transform: pos ? 'translate(' + pos[0] + 'px,' + pos[1] + 'px)' : 'translate(calc(100vw * 0.62 - 360px), 40px)',
      transition: 'transform .9s cubic-bezier(.2,.7,.2,1)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "nk-halo-luz",
    style: {
      width: '100%',
      height: '100%',
      borderRadius: '50%',
      background: 'radial-gradient(circle, rgba(198, 244, 50, 0.11) 0%, rgba(198, 244, 50, 0.04) 35%, rgba(198, 244, 50, 0) 65%)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      maxWidth: 1200,
      margin: '0 auto',
      padding: '112px 24px 128px',
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(min(460px, 100%), 1fr))',
      gap: 64,
      alignItems: 'center',
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "nk-entra"
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    kind: "prompt"
  }, "AI, Data & Automation")), /*#__PURE__*/React.createElement("h1", {
    className: "nk-entra-2",
    style: {
      margin: 0,
      fontFamily: SG,
      fontWeight: 700,
      fontSize: 'clamp(44px, 6vw, 76px)',
      lineHeight: 1.0,
      letterSpacing: '-2px',
      textWrap: 'balance'
    }
  }, "Datos que trabajan.", /*#__PURE__*/React.createElement("br", null), "Procesos que ", /*#__PURE__*/React.createElement("span", {
    style: {
      background: '#c6f432',
      color: '#111418',
      padding: '0 12px',
      display: 'inline-block'
    }
  }, "fluyen.")), /*#__PURE__*/React.createElement("p", {
    className: "nk-entra-3",
    style: {
      margin: 0,
      maxWidth: 520,
      color: '#9ca3af',
      fontSize: 19,
      textWrap: 'pretty'
    }
  }, "Dise\xF1amos el flujo de tu informaci\xF3n, automatizamos tus procesos y sumamos agentes de IA para que tu negocio decida mejor y trabaje menos."), /*#__PURE__*/React.createElement("div", {
    className: "nk-entra-3",
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Button, {
    onClick: () => go('contacto')
  }, "Agenda una reuni\xF3n"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    arrow: true,
    onClick: () => go('servicios')
  }, "Ver servicios"))), /*#__PURE__*/React.createElement(HeroVisual, null)));
}
window.Hero = Hero;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/Sections.jsx
try { (() => {
const DS = window.NniklabDesignSystem_cf651b;
const F = '../../assets/fotos/';
function Problems() {
  const {
    Section,
    SectionHeader,
    ProblemCard,
    FloatPanel,
    Chip,
    Icon
  } = DS;
  const mono = {
    fontFamily: "'JetBrains Mono', Consolas, monospace"
  };
  return /*#__PURE__*/React.createElement(Section, {
    tone: "alt"
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    label: "/lo_que_te_frena",
    title: /*#__PURE__*/React.createElement(React.Fragment, null, "\xBFTe suena familiar?", /*#__PURE__*/React.createElement("br", null), "Esto te quita tiempo y dinero.")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(min(260px, 100%), 1fr))',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(ProblemCard, {
    image: F + 'papeles-escritorio-tima-miroshnichenko.jpg',
    alt: "Escritorio cubierto de reportes impresos",
    index: "01",
    label: "DISPERSI\xD3N",
    text: "Tu informaci\xF3n est\xE1 repartida entre Excel, sistemas y correos."
  }, /*#__PURE__*/React.createElement(FloatPanel, null, [['XLS', 'ventas_final_v3.xlsx'], ['XLS', 'ventas_final_v3 (copia).xlsx'], ['@', 'Re: Re: reporte de ventas']].map(([t, n]) => /*#__PURE__*/React.createElement("div", {
    key: n,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Chip, {
    kind: "file"
  }, t), /*#__PURE__*/React.createElement("span", null, n))), /*#__PURE__*/React.createElement("div", {
    style: {
      ...mono,
      fontSize: 11,
      color: '#c6f432',
      paddingTop: 4,
      borderTop: '1px solid #2e333b'
    }
  }, "// 3 versiones, ninguna coincide"))), /*#__PURE__*/React.createElement(ProblemCard, {
    image: F + 'trabajo-nocturno-oktay-koseoglu.jpg',
    alt: "Persona trabajando sola de noche",
    index: "02",
    label: "TRABAJO MANUAL",
    text: "Cada semana alguien arma reportes a mano.",
    delay: 0.9
  }, /*#__PURE__*/React.createElement(FloatPanel, {
    row: true
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: '0 0 auto',
      width: 36,
      height: 36,
      background: '#c6f432',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "documento",
    color: "#111418"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 600
    }
  }, "Reporte semanal \xB7 pendiente"), /*#__PURE__*/React.createElement("span", {
    style: {
      ...mono,
      fontSize: 11,
      color: '#9ca3af'
    }
  }, "lunes 23:40 \xB7 faltan 4 hojas por consolidar")))), /*#__PURE__*/React.createElement(ProblemCard, {
    image: F + 'digitando-documento-vanessa-garcia.jpg',
    alt: "Hombre digitando un documento impreso",
    index: "03",
    label: "TAREAS REPETITIVAS",
    text: "Tu equipo pierde horas en tareas repetitivas.",
    delay: 1.4
  }, /*#__PURE__*/React.createElement(FloatPanel, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", null, "Digitando factura 128 de 340"), /*#__PURE__*/React.createElement("span", {
    style: {
      ...mono,
      color: '#9ca3af'
    }
  }, "38 %")), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 6,
      background: '#2e333b'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '38%',
      height: 6,
      background: '#c6f432'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      ...mono,
      fontSize: 11,
      color: '#9ca3af'
    }
  }, "copiar \u2192 pegar \u2192 revisar \u2192 repetir"))), /*#__PURE__*/React.createElement(ProblemCard, {
    image: F + 'duda-documento-kaboompics.jpg',
    alt: "Hombre revisando un documento con duda",
    index: "04",
    label: "DECISIONES A CIEGAS",
    text: "Las decisiones se toman sin datos confiables o a destiempo.",
    delay: 1.9
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#f4f4f2',
      color: '#111418',
      borderRadius: 8,
      padding: '10px 14px',
      fontSize: 14,
      fontWeight: 500
    }
  }, "\xBFCu\xE1nto vendimos este mes?"), /*#__PURE__*/React.createElement(FloatPanel, {
    row: true,
    style: {
      alignSelf: 'flex-end',
      gap: 8,
      padding: '8px 12px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "nk-latido",
    style: {
      width: 8,
      height: 8,
      background: '#c6f432',
      display: 'inline-block'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      ...mono,
      fontSize: 11
    }
  }, "datos de hace 3 semanas"))))));
}
function Services() {
  const {
    Section,
    SectionHeader,
    ServiceCard
  } = DS;
  return /*#__PURE__*/React.createElement(Section, {
    id: "servicios"
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    label: "/lo_que_hacemos",
    title: "Te ayudamos en tres frentes: datos, automatizaci\xF3n e IA.",
    aside: "Contr\xE1talos por separado o juntos: tus datos alimentan las automatizaciones y la IA trabaja sobre ambos."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(min(320px, 100%), 1fr))',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(ServiceCard, {
    icon: "datos",
    index: "01",
    title: "Datos",
    items: ['Arquitectura del flujo de información', 'ETL e ingeniería de datos', 'Análisis de datos', 'Dashboards para decidir'],
    note: "Conectamos ERP, contabilidad, facturaci\xF3n electr\xF3nica, CRM, Excel y m\xE1s.",
    result: "Informaci\xF3n centralizada y confiable para decidir."
  }), /*#__PURE__*/React.createElement(ServiceCard, {
    icon: "automatizacion",
    index: "02",
    title: "Automatizaci\xF3n",
    items: ['Automatizaciones que eliminan procesos manuales', 'Integración de aplicaciones: tus sistemas se hablan', 'Flujos que generan resultados solos'],
    result: "Menos trabajo manual y menos errores."
  }), /*#__PURE__*/React.createElement(ServiceCard, {
    icon: "ia",
    index: "03",
    title: "IA",
    items: ['Agentes que gestionan tu información', 'Agentes en tus automatizaciones: leen documentos, responden y deciden'],
    result: "Procesos que van m\xE1s all\xE1 de las reglas fijas."
  })));
}
const EXAMPLES = [['DATOS', 'Dashboard de ventas que se actualiza solo', 'Los datos del ERP y los Excel de cada sucursal se integran cada noche en un tablero de Power BI.'], ['DATOS', 'Una sola fuente de verdad', 'La información de varios sistemas, centralizada en un almacén de datos, con indicadores que todos leen igual.'], ['AUTOMATIZACIÓN', 'Reportes que llegan solos', 'El reporte semanal se genera y se envía por correo cada lunes, sin que nadie lo arme.'], ['AUTOMATIZACIÓN', 'Sistemas sincronizados', 'Un pedido registrado en el CRM se crea en el ERP y en facturación sin volver a digitarlo.'], ['IA', 'Facturas leídas por un agente', 'La IA extrae los datos de facturas y documentos, los valida y los carga al sistema.'], ['IA', 'Pregúntale a tus datos', 'Un agente responde en lenguaje natural preguntas como "¿cuánto vendimos ayer en Quito?".']];
function Examples() {
  const {
    Section,
    SectionHeader,
    ExampleCard,
    FlowCard
  } = DS;
  return /*#__PURE__*/React.createElement(Section, {
    id: "que-puedes-lograr",
    tone: "alt"
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    label: "/qu\xE9_puedes_lograr",
    title: "Lo que podemos construir para ti.",
    aside: "Procesos de ejemplo que se resuelven con nuestros servicios.",
    asideSize: 14
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(min(340px, 100%), 1fr))',
      gap: 24
    }
  }, EXAMPLES.map(([t, h, p]) => /*#__PURE__*/React.createElement(ExampleCard, {
    key: h,
    tag: t,
    title: h,
    text: p
  }))), /*#__PURE__*/React.createElement(FlowCard, {
    tag: "COMBINADO \xB7 DATOS + AUTOMATIZACI\xD3N + IA",
    title: "Un pedido, de principio a fin",
    steps: ['El cliente escribe por WhatsApp', 'Un agente interpreta el pedido', 'La automatización lo registra', 'El dashboard se actualiza']
  }));
}
function Process() {
  const {
    Section,
    SectionHeader,
    ProcessStep
  } = DS;
  return /*#__PURE__*/React.createElement(Section, {
    id: "como-trabajamos",
    tone: "light"
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    onLight: true,
    label: "/c\xF3mo_trabajamos",
    title: "Un proceso claro, de principio a fin.",
    aside: "Cuatro etapas. En cada una sabes qu\xE9 hacemos y qu\xE9 recibes.",
    asideSize: 17
  }), /*#__PURE__*/React.createElement("ol", {
    style: {
      margin: 0,
      padding: 0,
      listStyle: 'none',
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(min(250px, 100%), 1fr))',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(ProcessStep, {
    number: "01",
    icon: "diagnostico",
    title: "Diagn\xF3stico",
    text: "Entendemos tu negocio, tus procesos y tus datos.",
    receives: "Un mapa de tus procesos y fuentes de datos, con las oportunidades priorizadas.",
    pulseDelay: ""
  }), /*#__PURE__*/React.createElement(ProcessStep, {
    number: "02",
    icon: "diseno",
    title: "Dise\xF1o",
    text: "Definimos la soluci\xF3n y la arquitectura a tu medida.",
    receives: "La propuesta de soluci\xF3n: arquitectura, alcance y plan de trabajo.",
    pulseDelay: "nk-d2"
  }), /*#__PURE__*/React.createElement(ProcessStep, {
    number: "03",
    icon: "construccion",
    title: "Construcci\xF3n",
    text: "Desarrollamos, probamos y entregamos.",
    receives: "La soluci\xF3n funcionando, probada con tus datos reales.",
    pulseDelay: "nk-d4"
  }), /*#__PURE__*/React.createElement(ProcessStep, {
    number: "04",
    icon: "acompanamiento",
    title: "Acompa\xF1amiento",
    text: "Medimos resultados y mejoramos.",
    receives: "Seguimiento de resultados y mejoras continuas.",
    final: true
  })));
}
function Tech({
  go
}) {
  const {
    SectionHeader,
    TechCard
  } = DS;
  return /*#__PURE__*/React.createElement("section", {
    id: "tecnologias",
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      padding: 'clamp(64px, 8vw, 96px) 24px',
      display: 'flex',
      flexDirection: 'column',
      gap: 40,
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    label: "/tecnolog\xEDas",
    title: "Tecnolog\xEDas con las que trabajamos",
    aside: "Plataformas l\xEDderes del mercado, y nos adaptamos a las que ya usa tu empresa."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, minmax(0, 1fr))',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(TechCard, {
    icon: "nube",
    index: "01",
    title: "Datos y nube",
    text: "Donde se guardan, procesan y visualizan tus datos.",
    tools: ['Azure', 'Azure Databricks', 'Azure SQL', 'Data Factory', 'Microsoft Fabric', 'Power BI']
  }), /*#__PURE__*/React.createElement(TechCard, {
    icon: "bases",
    index: "02",
    title: "Bases de datos",
    text: "Nos conectamos a las bases que tu empresa ya usa.",
    tools: ['Oracle', 'SQL Server', 'PostgreSQL']
  }), /*#__PURE__*/React.createElement(TechCard, {
    icon: "flujo",
    index: "03",
    title: "Automatizaci\xF3n",
    text: "Flujos que conectan las aplicaciones de tu d\xEDa a d\xEDa.",
    tools: ['n8n', 'Power Automate', 'SharePoint', 'Microsoft 365']
  }), /*#__PURE__*/React.createElement(TechCard, {
    icon: "chispa",
    index: "04",
    title: "Inteligencia artificial",
    text: "Modelos para agentes que leen, responden y deciden.",
    tools: ['Azure OpenAI', 'API de OpenAI', 'API de Claude (Anthropic)']
  }), /*#__PURE__*/React.createElement(TechCard, {
    icon: "codigo",
    index: "05",
    title: "Desarrollo e integraci\xF3n",
    text: "C\xF3digo a la medida cuando una herramienta no alcanza.",
    tools: ['Python', 'APIs REST', 'Git / GitHub']
  }), /*#__PURE__*/React.createElement(TechCard, {
    accent: true,
    icon: "mas",
    index: "06",
    title: "\xBFUsas otra herramienta?",
    text: "Si tu empresa trabaja con otra plataforma, la evaluamos y la sumamos al flujo.",
    onCta: () => go('contacto')
  })));
}
function Team() {
  const {
    SectionLabel,
    TextLink
  } = DS;
  const SG = "'Space Grotesk', Arial, sans-serif";
  return /*#__PURE__*/React.createElement("section", {
    id: "equipo",
    style: {
      background: '#1a1d22',
      borderTop: '1px solid #2e333b',
      borderBottom: '1px solid #2e333b'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      padding: 'clamp(64px, 8vw, 96px) 24px',
      display: 'flex',
      flexDirection: 'column',
      gap: 48,
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16,
      maxWidth: 760
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, null, "/conoce_a_nuestro_equipo"), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: SG,
      fontWeight: 700,
      fontSize: 'clamp(32px, 4vw, 44px)',
      lineHeight: 1.1,
      letterSpacing: '-1.5px'
    }
  }, "Datos, automatizaci\xF3n e IA, con experiencia de proyecto real.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(min(360px, 100%), 1fr))',
      gap: '48px 64px',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    role: "img",
    "aria-label": "Espacio para la foto de Juan Heredia T.",
    style: {
      aspectRatio: '4 / 5',
      maxWidth: 440,
      width: '100%',
      border: '1px dashed #6b7280',
      borderRadius: 8,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: '#111418',
      color: '#9ca3af',
      fontFamily: "'JetBrains Mono', Consolas, monospace",
      fontSize: 13,
      letterSpacing: '1px'
    }
  }, "[FOTO DE JUAN]"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: SG,
      fontSize: 28,
      fontWeight: 700,
      letterSpacing: '-0.5px'
    }
  }, "Juan Heredia T."), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'JetBrains Mono', Consolas, monospace",
      fontSize: 14,
      color: '#c6f432'
    }
  }, "Mgs. Business Intelligence & Analytics"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 16,
      color: '#9ca3af'
    }
  }, "+10 a\xF1os en Proyectos de Arquitectura de Software y Datos")), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: '#9ca3af'
    }
  }, "En nniklab unimos datos, automatizaci\xF3n e inteligencia artificial para que los negocios trabajen con informaci\xF3n confiable y procesos que funcionan solos."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(min(160px, 100%), 1fr))',
      gap: 16
    }
  }, [['Arquitectura', 'de aplicaciones y datos'], ['Liderazgo', 'de equipos de datos y desarrollo'], ['Gestión ágil', 'de proyectos (Scrum)']].map(([a, b]) => /*#__PURE__*/React.createElement("div", {
    key: a,
    style: {
      borderTop: '1px solid #2e333b',
      paddingTop: 16,
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: SG,
      fontSize: 22,
      fontWeight: 500
    }
  }, a), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: '#9ca3af'
    }
  }, b)))), /*#__PURE__*/React.createElement(TextLink, {
    href: "https://www.linkedin.com/in/juanherediat/"
  }, "Ver perfil en LinkedIn")))));
}
const CL = [[110, 8, -2.7, 140, 6, -1.1], [80, 5, -3.2, 140, 5, -3.6], [140, 5, -.4, 80, 6, -3.6], [110, 5, -4, 110, 7, -2.4], [80, 5, -3.4, 80, 8, -.6], [80, 8, -2.3, 140, 8, -2.5], [110, 5, -5.8, 80, 6, -1.5], [80, 8, -3.1, 140, 6, -2.5]];
const CR = [[140, 8, -3.8, 80, 5, -2.7], [110, 8, -3.9, 140, 6, -3.7], [110, 7, -2.6, 80, 6, -3.8], [140, 5, -4.2, 110, 6, -3.1], [110, 8, -.4, 80, 5, -1.3], [140, 6, -4.7, 110, 7, -.5], [80, 5, -.4, 110, 6, -4.1], [110, 5, -2.4, 80, 5, -1.6]];
const TOPS = [14, 24, 34, 44, 56, 66, 76, 86];
function Closing() {
  const {
    SectionLabel,
    Button,
    TextLink
  } = DS;
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement("section", {
    id: "contacto",
    style: {
      position: 'relative',
      overflow: 'hidden',
      borderTop: '1px solid #2e333b',
      background: '#111418'
    }
  }, /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    className: "nk-cierre-flujos",
    style: {
      position: 'absolute',
      inset: 0,
      overflow: 'hidden',
      pointerEvents: 'none'
    }
  }, TOPS.map((t, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: t
  }, /*#__PURE__*/React.createElement("div", {
    className: "nk-flujo-linea",
    style: {
      top: t + '%',
      right: '50%'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "nk-flujo-seg",
    style: {
      width: CL[i][0],
      animationDuration: CL[i][1] + 's',
      animationDelay: CL[i][2] + 's'
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "nk-flujo-seg",
    style: {
      width: CL[i][3],
      animationDuration: CL[i][4] + 's',
      animationDelay: CL[i][5] + 's'
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "nk-flujo-linea",
    style: {
      top: t + '%',
      left: '50%'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "nk-flujo-seg nk-hacia-centro-der",
    style: {
      width: CR[i][0],
      animationDuration: CR[i][1] + 's',
      animationDelay: CR[i][2] + 's'
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "nk-flujo-seg nk-hacia-centro-der",
    style: {
      width: CR[i][3],
      animationDuration: CR[i][4] + 's',
      animationDelay: CR[i][5] + 's'
    }
  }))))), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      left: '50%',
      top: '50%',
      width: 0,
      height: 0,
      pointerEvents: 'none'
    }
  }, [0, 1.2, 2.4, 3.6, 4.8].map(d => /*#__PURE__*/React.createElement("span", {
    key: d,
    className: "nk-onda",
    style: {
      animationDelay: d + 's'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      left: '50%',
      top: '50%',
      width: 760,
      height: 760,
      transform: 'translate(-50%, -50%)',
      borderRadius: '50%',
      pointerEvents: 'none',
      background: 'radial-gradient(circle, rgba(198, 244, 50, 0.10) 0%, rgba(198, 244, 50, 0.03) 40%, rgba(198, 244, 50, 0) 68%)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      maxWidth: 1200,
      margin: '0 auto',
      padding: 'clamp(112px, 14vw, 176px) 24px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 32,
      textAlign: 'center',
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    kind: "prompt",
    boxed: true
  }, "siguiente_paso"), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: "'Space Grotesk', Arial, sans-serif",
      fontWeight: 700,
      fontSize: 'clamp(44px, 7vw, 88px)',
      lineHeight: 1.0,
      letterSpacing: '-2.5px',
      textWrap: 'balance'
    }
  }, "\xBFHablamos de tus ", /*#__PURE__*/React.createElement("span", {
    style: {
      background: '#c6f432',
      color: '#111418',
      padding: '0 12px',
      display: 'inline-block'
    }
  }, "datos"), "?"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      maxWidth: 540,
      color: '#c9ced6',
      fontSize: 19
    }
  }, "Cu\xE9ntanos qu\xE9 proceso te quita tiempo o qu\xE9 informaci\xF3n necesitas ver. Te proponemos c\xF3mo resolverlo."), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    glow: true,
    arrow: true,
    onClick: () => setSent(true)
  }, sent ? 'Formulario pendiente (n8n)' : 'Agenda una reunión'), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'center',
      gap: '12px 24px',
      fontFamily: "'JetBrains Mono', Consolas, monospace",
      fontSize: 13,
      color: '#9ca3af'
    }
  }, /*#__PURE__*/React.createElement("span", null, "o escr\xEDbenos:"), /*#__PURE__*/React.createElement(TextLink, {
    mono: true,
    glyph: "",
    color: "#f4f4f2",
    href: "mailto:nniklab@outlook.com"
  }, "nniklab@outlook.com"), /*#__PURE__*/React.createElement(TextLink, {
    mono: true,
    glyph: "",
    color: "#f4f4f2",
    href: "tel:+593995784113"
  }, "+593 99 578 4113"))));
}
Object.assign(window, {
  Problems,
  Services,
  Examples,
  Process,
  Tech,
  Team,
  Closing
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/Sections.jsx", error: String((e && e.message) || e) }); }

__ds_ns.ExampleCard = __ds_scope.ExampleCard;

__ds_ns.FlowCard = __ds_scope.FlowCard;

__ds_ns.FloatPanel = __ds_scope.FloatPanel;

__ds_ns.ProblemCard = __ds_scope.ProblemCard;

__ds_ns.ProcessStep = __ds_scope.ProcessStep;

__ds_ns.ServiceCard = __ds_scope.ServiceCard;

__ds_ns.TechCard = __ds_scope.TechCard;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.SectionLabel = __ds_scope.SectionLabel;

__ds_ns.TextLink = __ds_scope.TextLink;

__ds_ns.SectionHeader = __ds_scope.SectionHeader;

__ds_ns.Section = __ds_scope.Section;

__ds_ns.CarouselControls = __ds_scope.CarouselControls;

__ds_ns.Footer = __ds_scope.Footer;

__ds_ns.NavBar = __ds_scope.NavBar;

})();
