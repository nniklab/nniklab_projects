# nniklab Design System

**nniklab — AI, Data & Automation.** nniklab builds data and automation solutions for businesses of any size, with AI used across both lines:
- **Datos:** análisis, ingeniería y arquitectura de datos.
- **Automatización:** integración de aplicaciones y flujos de trabajo automáticos.
- **IA:** clasificar y extraer información de documentos, generar análisis y reportes, atender consultas, tomar decisiones dentro de procesos.

Contacto oficial: Juan Heredia T. · +593 99 578 4113 · nniklab@outlook.com

The main product surface is the **company website**: a single static page (HTML/CSS/JS, no build) at `company/05-web/sitio/`, version 1.4 (2026-10-19), published on GitHub Pages. It was designed in Claude Design from this system and is now the source of truth for UI.

## Sources
- GitHub: https://github.com/nniklab/nniklab_projects (branch `main`) — `company/` (lowercase since 2026-10-11) holds brand guides (`01-marca/colores`, `01-marca/tipografia`, `01-marca/logo`), verbal identity (`03-comunicacion/identidad-verbal.md`), web mockups (`05-web/`), advertising (`06-publicidad/`: intro video v2, music, brand graphics, photo backgrounds) and a backup orange palette (`99-respaldo/`, not in use). Explore this repo further when designing — new decisions (services catalogue, slogan, business card) will land there.
- Reference images copied to `assets/reference/`: official palette, typography sheet, logo presentation, both landing mockups.

## Index
- `styles.css` — entry point (imports only) → `tokens/fonts.css` (local @font-face), `colors.css`, `typography.css`, `spacing.css`, `motion.css` (brand keyframes + utility classes from the site), `base.css`
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand, Imagery)
- `components/` — React primitives (below)
- `ui_kits/web/` — recreation of the live site v1.4
- `assets/logo/` official logos · `assets/fonts/` woff2 (OFL) · `assets/icons/` site line icons + `icons/video/` Lucide set used in videos · `assets/fotos/` office photos · `assets/fondos/` photo backgrounds · `assets/graficos/` brand graphics · `assets/og-nniklab.jpg` · `assets/reference/` brand sheets
- `SKILL.md`, `github.md`, `thumbnail.html`

## Components
Inventory taken from the site's markup (`company/05-web/sitio/index.html`); there is no component library upstream.
- **core/**: Button, Icon, SectionLabel, Chip, TextLink, Logo
- **cards/**: ServiceCard, ProblemCard (+ FloatPanel), ExampleCard, FlowCard, ProcessStep, TechCard
- **layout/**: SectionHeader (+ Section)
- **navigation/**: NavBar, Footer, CarouselControls

Intentional additions: **Logo** (wraps the official SVGs) and **Icon** (exposes the site's inline SVG icons by name).

## UI kits
- `ui_kits/web/index.html` — Sitio nniklab v1.4: animated hero, Lo que te frena, Lo que hacemos, Qué puedes lograr, Cómo trabajamos, Tecnologías, Conoce a nuestro equipo, Cierre. Live site: https://nniklab.github.io/nniklab_projects/

---

## CONTENT FUNDAMENTALS
- **Language:** Spanish everywhere. The only English is the descriptor **"AI, Data & Automation"** — written exactly so ("AI" first, comma, "&").
- **Name:** always **nniklab**, lowercase, even at sentence start. Never "NnikLab", "NNIKLAB".
- **Address:** informal *tú* ("Tus datos, trabajando por ti", "para que tu negocio decida mejor"). The company speaks as *nosotros* in verbs ("Ordenamos", "Construimos", "Incorporamos").
- **Casing:** sentence case for headings and buttons. Caps only in short mono tags ("DISPERSIÓN", "RECIBES", "DATOS").
- **Tone:** clear, practical, outcome-first; short declarative headlines ending in a period ("Un proceso claro, de principio a fin."). Value = less work, better decisions. No hype, no jargon in headlines; technical words live in mono labels.
- **CTAs:** verb-first — "Agenda una reunión" (primary, everywhere), "Ver servicios →", "Conversemos →", "Ver perfil en LinkedIn ↗".
- **Highlight:** one word per headline gets lima ("trabajando", "resultados", "decisión.").
- **Slogan (official, 2026-10-17):** "Datos que trabajan. Procesos que fluyen." — hero of the site and close of the intro videos. Discarded: "Del dato a la decisión.", "Tus datos, trabajando por ti.".
- **Section labels:** path-style, snake_case, accents kept: `/lo_que_te_frena`, `/lo_que_hacemos`, `/qué_puedes_lograr`, `/cómo_trabajamos`, `/tecnologías`, `/conoce_a_nuestro_equipo`. Prompts: `> AI, Data & Automation_`, `> siguiente_paso_`. Log lines: `[ok] datos_validados`.
- **Headlines:** question or relatable pain first ("¿Te suena familiar? Esto te quita tiempo y dinero.", "¿Hablamos de tus datos?"), then a plain promise. One word gets a lima highlight block ("fluyen.", "datos").
- **Emoji:** never. Numbers as two-digit indices (01, 02…).

## VISUAL FOUNDATIONS
- **Color:** Grafito `#111418` base, Superficie `#1A1D22` for alternate sections and cards, Línea `#2E333B` for every border, Hueso `#F4F4F2` for the single light section, Lima `#C6F432` accent (hover `#D8FF52`). Secondary text `#9CA3AF` on dark, `#C9CED6` for slightly brighter captions; on light: `#4B5563` text, `#5E7A0E` accent, `#D9DBD6`/`#E3E4E0` borders, white cards. Never lima on white.
- **Type:** Space Grotesk 700 for H1/H2 (tight tracking −1.5 to −2.5px), 500 for H3/card titles; Inter 400–600 for body (18px/1.6, lead 19px) and buttons (600); JetBrains Mono for labels, indices, chips, logs. Hero H1 clamp(44–76px), closing H2 clamp(44–88px), section H2 clamp(32–44px).
- **Backgrounds:** flat colour fields alternating grafito / superficie, separated by 1px línea rules; one hueso section ("Cómo trabajamos"). Hero and closing add animated 1px data-flow lines with lima segments, masked by a radial fade, and a soft radial lima halo (≤11% alpha) — the only gradients besides photo protection. No textures.
- **Imagery:** real office photos of people (pain points) under a grafito protection gradient (25% → 55% → 97%). Warm-neutral photos; UI snippets float over them. Brand graphics and dark stock backgrounds for ads/video.
- **Cards:** radius 8, 1px línea border, superficie or grafito fill (contrast with the section ground), padding 24–32. Hover: border turns lima (lima oscuro on light) and card lifts 4px, 250ms. One highlighted card per section: lima border (flow card) or full lima fill (tech CTA card) or grafito on the light section.
- **Buttons:** square (radius 0). Primary lima/grafito text 600; hover `#D8FF52` + 1px lift. Secondary 1px línea outline; hover lima border + text. Dark (radius 4) only on lima surfaces; hover nudges 3px right.
- **Shadows:** none, except the pulsing lima ring on the closing CTA (`nk-brillo`).
- **Transparency & blur:** sticky header grafito 86% + 12px blur; floating panels over photos grafito 90% + 6px blur.
- **Square motif:** the logo's square dot recurs everywhere — status dots, process markers, pulses, carousel dots, closing ripples are all square. Never circles (except the halo light).
- **Animation:** CSS only, `cubic-bezier(.2,.7,.2,1)` for entrances (fade + 16px rise, staggered .15s), linear loops for data flows (5–12 s), blinking "_" cursor (1s steps), "latido" opacity pulse (2.4s), gentle 4px bob on floating panels. All disabled under prefers-reduced-motion.
- **Layout:** 1200px container, 24px gutters, sections 64–96px vertical (closing 112–176px), 48px between header and grid, 24px card gaps, auto-fit grids (min 250–340px). Sticky header ~76px. Mobile ≤760px: card grids become snap carousels with arrows and timed square dots.
- **Mobile scale (brand guide):** H1 40, H2 30, H3 22, body 16.

## ICONOGRAPHY
- **Site icons:** a small custom line set drawn inline in the site — 1.6px stroke at 40px (services, tech), 1.8px at 32px (process), square caps/corners, lima on dark, lima oscuro on light. Copied verbatim to `assets/icons/*.svg` (currentColor) and exposed via the `Icon` component: datos, automatizacion, ia, nube, bases, flujo, chispa, codigo, mas, diagnostico, diseno, construccion, acompanamiento, documento, flecha-izq, flecha-der.
- **Video icons:** Lucide (ISC) — bell, check, clock, mail, send, table in `assets/icons/video/`. For anything missing, use Lucide recoloured to the palette (the source recommends Lucide or Phosphor).
- **Unicode:** → for CTAs and flows, ↗ for external links, "_" as terminal cursor, "·" as separator.
- **Third-party logos:** `company/05-web/recursos/tecnologias/` holds 18 tech logos, reserved for a "Cómo se conectan" video/diagram. On the site technologies are **text-only mono chips** — no logos (decision 2026-10-17). Microsoft icons must keep their shape and carry the product name. Not copied here.
- **Brand marks:** `assets/logo/` — wordmark (oscuro/claro/mono-blanco/mono-negro; on lima use mono-negro), descriptor variants, "ni" icon variants, favicon.
- No emoji.

## Fonts
All three families ship as local woff2 files in `assets/fonts/` (SIL OFL, via Fontsource — copied from the site), declared in `tokens/fonts.css`. Weights: Space Grotesk 400/500/700, Inter 400/500/600, JetBrains Mono 400.
