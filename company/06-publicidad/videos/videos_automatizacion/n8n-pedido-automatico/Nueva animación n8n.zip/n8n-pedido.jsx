// n8n · El pedido que se registra solo — 1080×1920, guion: company/06-publicidad/videos/videos_automatizacion/n8n-pedido-automatico/README.md
const C = { bg: '#111418', sur: '#1A1D22', line: '#2E333B', hueso: '#F4F4F2', lima: '#C6F432', gris: '#9CA3AF', gris2: '#C9CED6', acero: '#6B7280' };
const FT = { title: "'Space Grotesk', sans-serif", body: "Inter, sans-serif", mono: "'JetBrains Mono', monospace" };
const MOTION = { enter: Easing.easeOutCubic, move: Easing.easeInOutCubic, pop: Easing.easeOutBack };
const pr = (T, a, b, e) => { const k = clamp((T - a) / (b - a), 0, 1); return e ? e(k) : k; };
const lerp = (a, b, k) => a + (b - a) * k;
function kf(T, pts) {
  if (T <= pts[0][0]) return pts[0][1];
  for (let i = 1; i < pts.length; i++) if (T <= pts[i][0]) {
    const [t0, v0] = pts[i - 1], [t1, v1] = pts[i];
    return t1 === t0 ? v1 : lerp(v0, v1, MOTION.move((T - t0) / (t1 - t0)));
  }
  return pts[pts.length - 1][1];
}
// in/out window → {o, y}
function win(T, a, b, fin = 0.5, fout = 0.5, rise = 18) {
  const i = pr(T, a, a + fin, MOTION.enter), o = b == null ? 0 : pr(T, b, b + fout, MOTION.enter);
  return { o: i * (1 - o), y: rise * (1 - i) - rise * o };
}

const ICONS = {
  mail: [<path key="a" d="m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7" />, <rect key="b" x="2" y="4" width="20" height="16" rx="2" />],
  sparkles: [<path key="a" d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z" />, <path key="b" d="M20 3v4" />, <path key="c" d="M22 5h-4" />],
  database: [<ellipse key="a" cx="12" cy="5" rx="9" ry="3" />, <path key="b" d="M3 5V19A9 3 0 0 0 21 19V5" />, <path key="c" d="M3 12A9 3 0 0 0 21 12" />],
  split: [<path key="a" d="M16 3h5v5" />, <path key="b" d="M8 3H3v5" />, <path key="c" d="M12 22v-8.3a4 4 0 0 0-1.172-2.872L3 3" />, <path key="d" d="m15 9 6-6" />],
  table: [<path key="a" d="M12 3v18" />, <rect key="b" width="18" height="18" x="3" y="3" rx="2" />, <path key="c" d="M3 9h18" />, <path key="d" d="M3 15h18" />],
  users: [<path key="a" d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />, <circle key="b" cx="9" cy="7" r="4" />, <path key="c" d="M22 21v-2a4 4 0 0 0-3-3.87" />, <path key="d" d="M16 3.13a4 4 0 0 1 0 7.75" />],
  bell: [<path key="a" d="M10.268 21a2 2 0 0 0 3.464 0" />, <path key="b" d="M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326" />],
  message: [<path key="a" d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z" />],
  check: [<path key="a" d="M20 6 9 17l-5-5" />],
};
const Ic = ({ name, size = 24, color = C.hueso, sw = 1.8 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" style={{ display: 'block' }}>{ICONS[name]}</svg>
);
const Clock = ({ size, color, angle }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" style={{ display: 'block' }}>
    <circle cx="12" cy="12" r="10" />
    <path d="M12 12V6" transform={`rotate(${angle} 12 12)`} />
    <path d="M12 12h3.5" transform={`rotate(${angle / 12} 12 12)`} />
  </svg>
);

const CHAIN = [
  { icon: 'mail', name: 'Nuevo pedido', sub: 'Gmail · Outlook', data: 'Pedido #1048 · Ana R.', y: 520 },
  { icon: 'sparkles', name: 'Extraer datos', sub: 'IA · OpenAI / Claude', data: '3 productos · $184,50', y: 720 },
  { icon: 'database', name: 'Consultar stock', sub: 'Base de datos', data: 'stock disponible', y: 920 },
  { icon: 'split', name: '¿Hay stock?', sub: 'IF', data: 'true', y: 1120 },
];
const FAN = [
  { icon: 'table', name: 'Guardar', sub: 'Sheets · Excel', data: 'fila 214', x: 210 },
  { icon: 'users', name: 'Registrar', sub: 'CRM', data: 'cliente ok', x: 430 },
  { icon: 'bell', name: 'Avisar', sub: 'Slack · Teams', data: '#ventas', x: 650 },
  { icon: 'message', name: 'Confirmar', sub: 'WhatsApp', data: 'enviado', x: 870 },
];
const FY = 1380, CX = 540;

function flowTimes(F0) {
  const pop = F0 + 2.4;
  const D = [0, 1, 2].map(k => F0 + 2.8 + k * 1.3), A = D.map(d => d + 0.9);
  const FD = [0, 1, 2, 3].map(j => F0 + 6.7 + j * 0.15), FA = FD.map(d => d + 1.0);
  return { pop, D, A, FD, FA, act: [pop, ...A, ...FA], appear: i => F0 + 0.4 + i * 0.25, toast: F0 + 8.4, pulseA: F0 + 8.8, pulseB: F0 + 10.4, exit: F0 + 10.6 };
}
function chainPos(t, tm) {
  if (t < tm.pop) return null;
  let y = CHAIN[0].y + 84;
  for (let k = 0; k < 3; k++) if (t >= tm.D[k]) y = lerp(k === 0 ? CHAIN[0].y + 84 : CHAIN[k].y, CHAIN[k + 1].y, pr(t, tm.D[k], tm.A[k], MOTION.move));
  return { x: CX, y };
}
function fanPos(t, tm, j) {
  if (t < tm.FD[j] || t > tm.FA[j] + 0.1) return null;
  const u = pr(t, tm.FD[j], tm.FA[j], MOTION.move), x = FAN[j].x;
  if (u < 0.15) return { x: CX, y: lerp(CHAIN[3].y, 1180, u / 0.15) };
  if (u > 0.85) return { x, y: lerp(FY - 56, FY, (u - 0.85) / 0.15) };
  const s = (u - 0.15) / 0.7, m = 1 - s;
  return {
    x: m * m * m * CX + 3 * m * m * s * CX + 3 * m * s * s * x + s * s * s * x,
    y: m * m * m * 1180 + 3 * m * m * s * 1260 + 3 * m * s * s * 1244 + s * s * s * (FY - 56),
  };
}

const rnd = (i, k) => { const v = Math.sin(i * 12.9898 + k * 78.233) * 43758.5453; return v - Math.floor(v); };
const OFF = 1.5; // intro "¿Te suena familiar?"
const CUT = 5.8; // duración del caos; luego corte seco
const CYC = (() => { const d = [1.1, 0.8, 0.6, 0.45, 0.36, 0.3, 0.28, 0.26]; let t = 0.8; return d.map(x => { const c = { s: t, d: x, copy: t + x * 0.45, paste: t + x }; t += x; return c; }); })();
const ROWS = [['#1048', 'Ana R.', '$184,50'], ['#1049', 'Luis M.', '$62,00'], ['#1050', 'Carla P.', '$310,20'], ['#1050', 'Carla P.', '$310,20'], ['#1051', 'Jorge T.', '$45,90'], ['#1052', 'Sofía V.', '$128,00'], ['#1053', 'Pedro L.', '$77,40'], ['#1054', 'Marta G.', '$203,10']];
const ERR_ROW = 3;
const APPS = [['mail', 'Gmail'], ['message', 'WhatsApp'], ['mail', 'Outlook'], ['table', 'Excel'], ['bell', 'Teams'], ['bell', 'Slack']];
const MSGS = ['Nuevo pedido #1055', '¿Ya enviaron mi pedido?', 'URGENTE: falta la factura', 'Te reenvío el pedido', '¿Me confirmas el stock?', 'Pedido modificado', 'Recordatorio: responder al cliente', '3 mensajes nuevos', 'Nuevo pedido #1056', '¿Cuándo llega?'];
const NOTIS = Array.from({ length: 26 }, (_, i) => ({ t: 2.2 + 3.5 * Math.sqrt(i / 26), x: 120 + rnd(i, 1) * 240, y: 640 + rnd(i, 2) * 880, r: (rnd(i, 3) - 0.5) * 9, app: APPS[i % APPS.length], msg: MSGS[(i * 7) % MSGS.length] }));
const EMAIL_PT = { x: 700, y: 730 }, rowPt = k => ({ x: 470, y: 860 + 64 + 44 + k * 50 + 25 });

function Headline({ T, P0, R0 }) {
  const Q = P0 + OFF, a = win(T, Q, Q + 2.4, 0.6, 0.3), b = win(T, Q + 2.6, Q + CUT + 1, 0.5, 0.01);
  const c = win(T, R0 + 0.1, R0 + 3.8, 0.6, 0.5);
  const base = { position: 'absolute', left: 120, top: 340, width: 840, fontFamily: FT.title, fontWeight: 700, fontSize: 72, lineHeight: 1.04, letterSpacing: -2.5, color: C.hueso, textWrap: 'pretty' };
  return (
    <React.Fragment>
      <Shot from={Q} to={Q + CUT}>
        <div style={{ ...base, opacity: a.o, transform: 'translateY(' + a.y + 'px)' }}>Llega un pedido…</div>
        <div style={{ ...base, opacity: b.o, transform: 'translateY(' + b.y + 'px)' }}>¿Cuánto <span style={{ color: C.lima }}>tiempo</span> pierdes copiando y pegando?</div>
      </Shot>
      <div style={{ ...base, opacity: c.o, transform: 'translateY(' + c.y + 'px)' }}>Ahora se hace <span style={{ color: C.lima }}>solo.</span></div>
    </React.Fragment>
  );
}

function Cursor({ T, P0 }) {
  const ts = [P0 + 0.6], xs = [900], ys = [1560];
  let px = 900, py = 1560;
  CYC.forEach((c, k) => { const r = rowPt(k);
    ts.push(P0 + c.s, P0 + c.copy, P0 + c.s + c.d * 0.55, P0 + c.paste); xs.push(px, EMAIL_PT.x, EMAIL_PT.x, r.x); ys.push(py, EMAIL_PT.y, EMAIL_PT.y, r.y); px = r.x; py = r.y; });
  const x = kf(T, ts.map((t, i) => [t, xs[i]])), y = kf(T, ts.map((t, i) => [t, ys[i]]));
  let tag = null;
  CYC.forEach(c => { if (T >= P0 + c.copy && T < P0 + c.copy + 0.22) tag = 'Ctrl+C'; if (T >= P0 + c.paste && T < P0 + c.paste + 0.22) tag = 'Ctrl+V'; });
  return (
    <div style={{ position: 'absolute', left: x, top: y, opacity: pr(T, P0 + 0.5, P0 + 0.8) }}>
      <svg width="46" height="46" viewBox="0 0 24 24" style={{ display: 'block' }}><path d="M4 2.5v17.5l4.6-4.4 3.1 6.9 3-1.3-3.1-6.8h6.4Z" fill={C.hueso} stroke={C.bg} strokeWidth="1.4" strokeLinejoin="round" /></svg>
      {tag && <div style={{ position: 'absolute', left: 40, top: 40, padding: '4px 10px', background: C.hueso, color: C.bg, fontFamily: FT.mono, fontSize: 20, whiteSpace: 'nowrap' }}>{tag}</div>}
    </div>
  );
}

function Chaos({ T, P0: P00 }) {
  const P0 = P00 + OFF, t = T - P0;
  const A = 11 * pr(t, 2.4, CUT, Easing.easeInQuad);
  const sx = A * Math.sin(t * 53), sy = A * Math.cos(t * 41);
  let k = -1; CYC.forEach((c, i) => { if (t >= c.s) k = i; });
  const ek = Math.max(0, k), mail = ROWS[ek];
  const fresh = k >= 0 ? pr(t, CYC[k].s, CYC[k].s + 0.18, MOTION.enter) : 1;
  const selected = k >= 0 && t >= CYC[k].copy && t < CYC[k].paste;
  const shown = Math.min(8, CYC.filter(c => t >= c.paste).length);
  const spawned = NOTIS.filter(n => t >= n.t).length;
  const mins = Math.round(15 * Math.pow(pr(t, 0.6, CUT), 1.6));
  const inO = pr(t, 0, 0.6, MOTION.enter);
  return (
    <Shot from={P0} to={P0 + CUT}>
      <div style={{ position: 'absolute', inset: 0, overflow: 'hidden' }}>
        <img src="assets/trabajo-nocturno.jpg" alt="" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', objectPosition: '34% 50%', transform: 'scale(' + (1.06 + 0.12 * pr(t, 0, CUT)) + ') translate(' + sx * 0.4 + 'px,' + sy * 0.4 + 'px)', opacity: inO }} />
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(17,20,24,.6) 0%, rgba(17,20,24,.45) 45%, rgba(17,20,24,.92) 100%)' }} />
      </div>
      <div style={{ position: 'absolute', left: 120, top: 268, width: 840, display: 'flex', justifyContent: 'space-between', alignItems: 'center', opacity: pr(t, 0.6, 1.0, MOTION.enter) }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ minWidth: 44, height: 44, padding: '0 10px', boxSizing: 'border-box', background: C.hueso, color: C.bg, fontFamily: FT.mono, fontSize: 24, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: 'scale(' + (spawned ? 1 + 0.15 * Math.max(0, 1 - (t - NOTIS[spawned - 1].t) / 0.15) : 1) + ')' }}>{3 + spawned}</div>
          <div style={{ fontFamily: FT.mono, fontSize: 24, color: C.gris2 }}>sin leer</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <Clock size={44} color={C.gris2} angle={t * (300 + 180 * t)} />
          <div style={{ fontFamily: FT.mono, fontSize: 34, color: C.gris2, minWidth: 130 }}>{mins} min</div>
        </div>
      </div>
      <div style={{ position: 'absolute', inset: 0, transform: 'translate(' + sx + 'px,' + sy + 'px)' }}>
        <div style={{ position: 'absolute', left: 120, top: 650, width: 840, boxSizing: 'border-box', padding: '20px 24px', background: C.sur, border: '1px solid ' + C.line, borderRadius: 8, display: 'flex', alignItems: 'center', gap: 20, opacity: pr(t, 0.4, 0.8, MOTION.enter) }}>
          <div style={{ width: 56, height: 56, flex: 'none', background: C.line, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Ic name="mail" size={30} /></div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, opacity: fresh, transform: 'translateY(' + 10 * (1 - fresh) + 'px)' }}>
            <div style={{ fontFamily: FT.mono, fontSize: 18, color: C.gris }}>Gmail · ahora</div>
            <div style={{ fontFamily: FT.body, fontWeight: 500, fontSize: 28, color: C.hueso }}>Pedido <span style={{ background: selected ? C.acero : 'transparent' }}>{mail[0]} · {mail[1]} · {mail[2]}</span></div>
          </div>
        </div>
        <div style={{ position: 'absolute', left: 120, top: 860, width: 840, boxSizing: 'border-box', background: C.sur, border: '1px solid ' + C.line, borderRadius: 8, overflow: 'hidden', opacity: pr(t, 0.5, 0.9, MOTION.enter) }}>
          <div style={{ height: 64, display: 'flex', alignItems: 'center', gap: 14, padding: '0 24px', borderBottom: '1px solid ' + C.line }}>
            <Ic name="table" size={26} color={C.gris} />
            <div style={{ fontFamily: FT.mono, fontSize: 20, color: C.gris }}>pedidos.xlsx</div>
          </div>
          <div style={{ height: 44, display: 'grid', gridTemplateColumns: '150px 1fr 190px', alignItems: 'center', padding: '0 24px', fontFamily: FT.mono, fontSize: 17, color: C.gris, borderBottom: '1px solid ' + C.line }}><div>#</div><div>cliente</div><div>total</div></div>
          {ROWS.map((r, i) => {
            const vis = i < shown, at = P0 + CYC[i].paste, err = i === ERR_ROW && vis;
            const jig = err ? 8 * Math.sin((T - at) * 60) * (1 - pr(T, at, at + 0.4)) : 0;
            return (
              <div key={i} style={{ position: 'relative', height: 50, display: 'grid', gridTemplateColumns: '150px 1fr 190px', alignItems: 'center', padding: '0 24px', fontFamily: FT.body, fontSize: 24, color: err ? C.gris : C.hueso, background: err ? C.line : 'transparent', borderBottom: '1px solid ' + C.line, opacity: vis ? pr(T, at, at + 0.12) : 0, transform: 'translateX(' + jig + 'px)' }}>
                <div style={{ fontFamily: FT.mono, fontSize: 21 }}>{r[0]}</div><div>{r[1]}</div><div>{r[2]}</div>
                {err && <div style={{ position: 'absolute', right: 16, top: 11, padding: '2px 10px', background: C.hueso, color: C.bg, fontFamily: FT.mono, fontSize: 17 }}>[error] dato_duplicado</div>}
              </div>
            );
          })}
        </div>
        <Cursor T={T} P0={P0} />
        {NOTIS.map((n, i) => {
          if (t < n.t) return null;
          const e = pr(t, n.t, n.t + 0.26, MOTION.pop), dim = 1 - 0.25 * pr(t, n.t + 0.3, n.t + 1.2);
          return (
            <div key={i} style={{ position: 'absolute', left: n.x, top: n.y, width: 600, boxSizing: 'border-box', padding: '18px 22px', background: C.sur, border: '1px solid ' + C.line, borderRadius: 8, display: 'flex', alignItems: 'center', gap: 18, opacity: clamp(e, 0, 1) * dim, transform: 'translateX(' + 140 * (1 - e) + 'px) rotate(' + n.r + 'deg) scale(' + (0.9 + 0.1 * e) + ')' }}>
              <div style={{ width: 48, height: 48, flex: 'none', background: C.line, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Ic name={n.app[0]} size={26} /></div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 4, minWidth: 0 }}>
                <div style={{ fontFamily: FT.mono, fontSize: 17, color: C.gris }}>{n.app[1]} · ahora</div>
                <div style={{ fontFamily: FT.body, fontWeight: 500, fontSize: 26, color: C.hueso, whiteSpace: 'nowrap' }}>{n.msg}</div>
              </div>
            </div>
          );
        })}
      </div>
    </Shot>
  );
}

function Familiar({ T, P0, F0 }) {
  const big = { position: 'absolute', left: 120, right: 120, textAlign: 'center', fontFamily: FT.title, fontWeight: 700, fontSize: 88, letterSpacing: -2.5, lineHeight: 1.05, color: C.hueso };
  const e = pr(T, P0, P0 + 0.45, MOTION.enter);
  const o1 = T < P0 + OFF ? e : 0, s1 = 1.06 - 0.06 * e + 0.02 * pr(T, P0 + 0.45, P0 + OFF);
  const M = P0 + OFF + CUT, m = T >= M && T < F0 ? pr(T, M, M + 0.5, MOTION.enter) * (1 - pr(T, F0 - 0.4, F0, MOTION.enter)) : 0;
  const caret = Math.floor((T - M) / 0.5) % 2 === 0 ? 1 : 0;
  return (
    <React.Fragment>
      <div style={{ ...big, top: 880, opacity: o1, transform: 'scale(' + s1 + ')' }}>¿Te suena <span style={{ background: C.lima, color: C.bg, padding: '0 12px' }}>familiar?</span></div>
      <div style={{ position: 'absolute', left: 120, right: 120, top: 840, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 28, opacity: m, transform: 'translateY(' + 18 * (1 - pr(T, M, M + 0.5, MOTION.enter)) + 'px)' }}>
        <div style={{ ...big, position: 'static' }}>Hay una forma <span style={{ background: C.lima, color: C.bg, padding: '0 12px' }}>mejor.</span></div>
        <div style={{ fontFamily: FT.mono, fontSize: 28, color: C.gris2 }}>&gt; automatízalo<span style={{ opacity: caret }}>_</span></div>
      </div>
    </React.Fragment>
  );
}

const MOTES = Array.from({ length: 18 }, (_, i) => ({ x: 60 + rnd(i, 11) * 960, y: rnd(i, 12) * 1920, sz: 4 + Math.round(rnd(i, 13) * 6), sp: 18 + rnd(i, 14) * 40, ph: rnd(i, 15) * 6.28 }));
function Particles({ T, F0, K0 }) {
  const o = pr(T, F0 - 0.2, F0 + 1.0, MOTION.enter) * (1 - pr(T, K0 - 0.7, K0, MOTION.enter));
  if (o <= 0) return null;
  const t = T - F0;
  const img = { position: 'absolute', left: -240, top: -160, width: 1560, height: 2240, objectFit: 'cover' };
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', opacity: o }}>
      <img src="assets/particulas.jpg" alt="" style={{ ...img, objectPosition: '70% 50%', transform: 'translate(' + (-t * 6) + 'px,' + (-t * 9) + 'px) scale(' + (1 + t * 0.006) + ') rotate(' + t * 0.25 + 'deg)' }} />
      <img src="assets/particulas.jpg" alt="" style={{ ...img, objectPosition: '20% 50%', mixBlendMode: 'screen', opacity: 0.35 + 0.1 * Math.sin(t * 1.3), transform: 'scaleX(-1) translate(' + (t * 10) + 'px,' + (-t * 16) + 'px) scale(' + (1.25 + t * 0.01) + ')' }} />
      {MOTES.map((m, i) => {
        const y = ((m.y - t * m.sp) % 1920 + 1920) % 1920;
        return <div key={i} style={{ position: 'absolute', left: m.x + 14 * Math.sin(t * 0.6 + m.ph), top: y, width: m.sz, height: m.sz, background: C.lima, opacity: 0.18 + 0.22 * (0.5 + 0.5 * Math.sin(t * 1.7 + m.ph)) }} />;
      })}
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(17,20,24,.86) 0%, rgba(17,20,24,.72) 50%, rgba(17,20,24,.9) 100%)' }} />
    </div>
  );
}

function Node({ T, tm, i, n, x, y, size, below }) {
  const ap = tm.appear(i), at = tm.act[i], ex = tm.exit + i * 0.08;
  const o = pr(T, ap, ap + 0.5, MOTION.enter) * (1 - pr(T, ex, ex + 0.5, MOTION.enter));
  const rise = 20 * (1 - pr(T, ap, ap + 0.5, MOTION.enter));
  const on = T >= at, sc = 1 + 0.07 * Math.sin(Math.PI * pr(T, at, at + 0.35));
  const pulse = T > tm.pulseA && T < tm.pulseB ? 0.6 + 0.4 * Math.cos(2 * Math.PI * (T - tm.pulseA) / 0.8) : 1;
  const border = on ? `rgba(198,244,50,${pulse})` : C.line;
  const typed = n.data.slice(0, Math.floor(n.data.length * pr(T, at + 0.1, at + 0.45)));
  const h = size / 2;
  return (
    <div style={{ position: 'absolute', left: 0, top: 0, width: 1080, height: 1920, opacity: o, transform: `translateY(${rise}px)` }}>
      <div style={{ position: 'absolute', left: x - h, top: y - h, width: size, height: size, boxSizing: 'border-box', background: C.sur, border: `2px solid ${border}`, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${sc})` }}>
        <Ic name={n.icon} size={size * 0.44} color={on ? C.hueso : C.gris} />
        <div style={{ position: 'absolute', left: h - 6, top: -7, width: 12, height: 12, background: on ? C.lima : C.line }} />
        {!below && <div style={{ position: 'absolute', left: h - 6, bottom: -7, width: 12, height: 12, background: on ? C.lima : C.line }} />}
        {on && <div style={{ position: 'absolute', right: -14, top: -14, width: 34, height: 34, background: C.lima, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${pr(T, at, at + 0.3, MOTION.pop)})` }}><Ic name="check" size={22} color={C.bg} sw={3} /></div>}
      </div>
      {below ? (
        <div style={{ position: 'absolute', left: x - 105, top: y + h + 18, width: 210, textAlign: 'center', display: 'flex', flexDirection: 'column', gap: 6 }}>
          <div style={{ fontFamily: FT.body, fontWeight: 500, fontSize: 25, color: C.hueso }}>{n.name}</div>
          <div style={{ fontFamily: FT.mono, fontSize: 17, color: C.gris }}>{n.sub}</div>
          <div style={{ fontFamily: FT.mono, fontSize: 17, color: C.lima, height: 22 }}>{typed}</div>
        </div>
      ) : (
        <React.Fragment>
          <div style={{ position: 'absolute', left: x + h + 28, top: y - 38, display: 'flex', flexDirection: 'column', gap: 8, whiteSpace: 'nowrap' }}>
            <div style={{ fontFamily: FT.body, fontWeight: 500, fontSize: 30, color: C.hueso }}>{n.name}</div>
            <div style={{ fontFamily: FT.mono, fontSize: 20, color: C.gris }}>{n.sub}</div>
          </div>
          <div style={{ position: 'absolute', right: 1080 - (x - h - 28), top: y - 14, display: 'flex', alignItems: 'center', gap: 10, whiteSpace: 'nowrap', opacity: typed ? 1 : 0 }}>
            <div style={{ width: 10, height: 10, background: C.lima }} />
            <div style={{ fontFamily: FT.mono, fontSize: 21, color: C.hueso }}>{typed}</div>
          </div>
        </React.Fragment>
      )}
    </div>
  );
}

function Packet({ p, op = 1, s = 1 }) {
  return <div style={{ position: 'absolute', left: p.x - 14, top: p.y - 14, width: 28, height: 28, background: C.lima, opacity: op, transform: `scale(${s})` }} />;
}

function Flow({ T, F0, grid }) {
  const tm = flowTimes(F0);
  const s = kf(T, [[F0 + 2.2, 1], [F0 + 3.0, 1.08], [F0 + 6.5, 1.08], [F0 + 7.3, 1], [F0 + 10.6, 1.03]]);
  const cy = kf(T, [[F0 + 2.2, 960], [F0 + 3.0, 640], [tm.D[0], 640], [tm.A[0] + 0.3, 760], [tm.D[1], 760], [tm.A[1] + 0.3, 860], [tm.D[2], 860], [tm.A[2], 960], [F0 + 6.5, 960], [F0 + 7.3, 960]]);
  const head = win(T, F0, tm.exit, 0.6, 0.5);
  const toast = win(T, tm.toast, tm.exit + 0.3, 0.5, 0.5);
  const gridO = (grid ? 1 : 0) * pr(T, F0, F0 + 0.8) * (1 - pr(T, tm.exit + 0.4, tm.exit + 1.0));
  const linesO = 1 - pr(T, tm.exit + 0.2, tm.exit + 0.8, MOTION.enter);
  const packets = [];
  const add = (fn, key) => {
    const p = fn(T); if (!p) return;
    for (let k = 4; k >= 1; k--) { const g = fn(T - 0.04 * k); if (g && Math.hypot(g.x - p.x, g.y - p.y) > 3) packets.push(<Packet key={key + 'g' + k} p={g} op={0.35 * (1 - k / 5)} />); }
    packets.push(<Packet key={key} p={p} s={key === 'c' ? pr(T, tm.pop, tm.pop + 0.4, MOTION.pop) : 1} />);
  };
  if (T < tm.FD[0] + 0.2) add(t => chainPos(t, tm), 'c');
  FAN.forEach((_, j) => add(t => fanPos(t, tm, j), 'f' + j));
  const cp = chainPos(T, tm);
  return (
    <React.Fragment>
      <div style={{ position: 'absolute', inset: 0, transformOrigin: '0 0', transform: `translate(540px,960px) scale(${s}) translate(-540px,${-cy}px)` }}>
        <svg width="1080" height="1920" style={{ position: 'absolute', left: 0, top: 0, overflow: 'visible' }}>
          <defs><pattern id="nkgrid" width="72" height="72" patternUnits="userSpaceOnUse"><path d="M72 0H0V72" fill="none" stroke="rgba(255,255,255,.05)" strokeWidth="1" /></pattern></defs>
          <rect x="-500" y="-500" width="2080" height="2920" fill="url(#nkgrid)" opacity={gridO} />
          <g opacity={linesO}>
            {[0, 1, 2].map(k => {
              const y1 = CHAIN[k].y + 60, y2 = CHAIN[k + 1].y - 60, g = pr(T, tm.appear(k + 1) - 0.1, tm.appear(k + 1) + 0.3, MOTION.enter);
              const le = T >= tm.D[k] && cp ? Math.min(y2, Math.max(y1, cp.y)) : y1;
              return <g key={k}><line x1={CX} x2={CX} y1={y1} y2={lerp(y1, y2, g)} stroke={C.line} strokeWidth="3" />{le > y1 && <line x1={CX} x2={CX} y1={y1} y2={le} stroke={C.lima} strokeWidth="3" />}</g>;
            })}
            {FAN.map((n, j) => {
              const d = `M${CX} 1180 C${CX} 1260 ${n.x} 1244 ${n.x} ${FY - 56}`, g = pr(T, tm.appear(4 + j) - 0.1, tm.appear(4 + j) + 0.3, MOTION.enter);
              const q = clamp((pr(T, tm.FD[j], tm.FA[j], MOTION.move) - 0.15) / 0.7, 0, 1);
              return <g key={j}><path d={d} pathLength="1" fill="none" stroke={C.line} strokeWidth="3" strokeDasharray="1 1" strokeDashoffset={1 - g} />{q > 0 && <path d={d} pathLength="1" fill="none" stroke={C.lima} strokeWidth="3" strokeDasharray="1 1" strokeDashoffset={1 - q} />}</g>;
            })}
          </g>
        </svg>
        {packets}
        {CHAIN.map((n, i) => <Node key={i} T={T} tm={tm} i={i} n={n} x={CX} y={n.y} size={120} />)}
        {FAN.map((n, j) => <Node key={'f' + j} T={T} tm={tm} i={4 + j} n={n} x={n.x} y={FY} size={112} below />)}
      </div>
      <div style={{ position: 'absolute', left: 120, top: 270, width: 840, display: 'flex', flexDirection: 'column', gap: 10, opacity: head.o, transform: `translateY(${head.y}px)` }}>
        <div style={{ fontFamily: FT.body, fontWeight: 500, fontSize: 36, color: C.gris2 }}>Con un flujo automático en n8n</div>
        <div style={{ fontFamily: FT.mono, fontSize: 22, color: C.gris }}>// registro_automático_de_pedidos</div>
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 1580, display: 'flex', justifyContent: 'center', opacity: toast.o, transform: `translateY(${-toast.y}px)` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 24px', background: C.sur, border: `1px solid ${C.line}`, borderRadius: 8 }}>
          <div style={{ width: 14, height: 14, background: C.lima }} />
          <div style={{ fontFamily: FT.mono, fontSize: 24, color: C.hueso }}>[ok] flujo_ejecutado · 8 nodos</div>
        </div>
      </div>
    </React.Fragment>
  );
}

function Result({ T, R0 }) {
  const blk = win(T, R0 + 0.9, R0 + 3.8, 0.5, 0.5);
  const strike = pr(T, R0 + 1.3, R0 + 1.7, MOTION.move);
  const big = pr(T, R0 + 1.8, R0 + 2.2, MOTION.pop);
  const l1 = win(T, R0 + 4.4, R0 + 7.3, 0.6, 0.6), l2 = win(T, R0 + 5.0, R0 + 7.3, 0.6, 0.6);
  const line = { fontFamily: FT.title, fontWeight: 700, fontSize: 100, lineHeight: 1.05, letterSpacing: -2.5, color: C.hueso };
  return (
    <React.Fragment>
      <div style={{ position: 'absolute', left: 120, top: 640, width: 840, display: 'flex', alignItems: 'center', gap: 28, opacity: blk.o, transform: `translateY(${blk.y}px)` }}>
        <Clock size={52} color={C.gris} angle={0} />
        <div style={{ position: 'relative', fontFamily: FT.mono, fontSize: 42, color: C.gris }}>
          15 min
          <div style={{ position: 'absolute', left: -4, top: '52%', height: 5, width: `calc(${strike * 100}% + 8px)`, background: C.lima }} />
        </div>
        <div style={{ fontFamily: FT.mono, fontSize: 42, color: C.gris, opacity: big }}>→</div>
        <div style={{ fontFamily: FT.title, fontWeight: 700, fontSize: 150, letterSpacing: -4, color: C.lima, lineHeight: 1, opacity: clamp(big, 0, 1), transform: `scale(${big})`, transformOrigin: '0 60%' }}>3 s</div>
      </div>
      <div style={{ position: 'absolute', left: 120, top: 720, width: 840, display: 'flex', flexDirection: 'column', gap: 44 }}>
        <div style={{ ...line, opacity: l1.o, transform: `translateY(${l1.y}px)` }}>Automatiza lo repetitivo.</div>
        <div style={{ ...line, opacity: l2.o, transform: `translateY(${l2.y}px)` }}>Dedícate a lo <span style={{ background: C.lima, color: C.bg, padding: '0 12px' }}>importante.</span></div>
      </div>
    </React.Fragment>
  );
}

// Escena 4 = cierre-logo-tecleado.html, mismos tiempos, relativos a CUES.Cierre
const RIGHT = [110.0, 225.2, 269.6, 385.6, 419.6, 536.8, 652.0], GAP = 9, CW = 34, CH = 99.2, DOT = { x: 240, y: -140 };
const KEYS = []; { let k = 1.0; [0, .15, .12, .17, .13, .16, .12].forEach(dt => { k += dt; KEYS.push(k); }); }
const TYPED_END = KEYS[6], JUMP_A = TYPED_END + 0.45, JUMP_B = JUMP_A + 0.45;
function Closing({ T, K0, firma }) {
  const t = T - K0;
  if (t < 0 || !window.NK_LOGO) return null;
  let typed = 0; KEYS.forEach((k, i) => { if (t >= k) typed = i + 1; });
  let x = typed === 0 ? 14 : RIGHT[typed - 1] + GAP, y = -CH, h = CH, op = 1;
  if (t < JUMP_A) {
    const typing = t >= KEYS[0] - 0.05 && t < TYPED_END + 0.15;
    if (!typing) op = Math.floor(t / 0.4) % 2 === 0 ? 1 : 0;
    if (t < 0.15) op = 0;
  } else {
    const j = MOTION.move(pr(t, JUMP_A, JUMP_B));
    x = lerp(RIGHT[6] + GAP, DOT.x, j); h = lerp(CH, CW, clamp(j * 1.6, 0, 1));
    y = lerp(-CH, DOT.y, j) - 70 * Math.sin(j * Math.PI);
    const b = pr(t, JUMP_B, JUMP_B + 0.35);
    if (t >= JUMP_B) y = DOT.y + 9 * Math.sin(b * Math.PI) * (1 - b);
  }
  const pk = pr(t, JUMP_B + 0.15, JUMP_B + 0.95), ps = CW + 80 * MOTION.enter(pk);
  const wipe = 680 * MOTION.enter(pr(t, JUMP_B + 0.3, JUMP_B + 1.0));
  const f = firma ? pr(t, JUMP_B + 1.3, JUMP_B + 1.9, MOTION.enter) : 0;
  return (
    <React.Fragment>
      <svg width="1080" height="1920" viewBox="0 0 1080 1920" style={{ position: 'absolute', left: 0, top: 0 }}>
        <defs><clipPath id="nkwipe"><rect x="0" y="0" width={wipe} height="120" /></clipPath></defs>
        <g transform="translate(160,960) scale(1.15)">
          {window.NK_LOGO.letters.map((d, i) => <path key={i} d={d} fill={C.hueso} opacity={pr(t, KEYS[i], KEYS[i] + 0.04)} />)}
          <g clipPath="url(#nkwipe)"><g transform="translate(2,62.7)"><path d={window.NK_LOGO.desc} fill={C.gris} /></g></g>
          {pk > 0 && pk < 1 && <rect x={DOT.x + CW / 2 - ps / 2} y={DOT.y + CW / 2 - ps / 2} width={ps} height={ps} fill="none" stroke={C.lima} strokeWidth="3.5" opacity={0.8 * (1 - pk)} />}
          <rect x={x} y={y} width={CW} height={h} fill={C.lima} opacity={op} />
        </g>
      </svg>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 1560, textAlign: 'center', fontFamily: FT.mono, fontSize: 24, color: C.gris, opacity: f, transform: `translateY(${10 * (1 - f)}px)` }}>Construido con n8n</div>
    </React.Fragment>
  );
}

function Piece({ grid, firma }) {
  const { T, CUES } = useComposition();
  const P0 = CUES.Problema, F0 = CUES.Flujo, R0 = CUES.Resultado, K0 = CUES.Cierre;
  return (
    <div data-screen-label={`t=${Math.floor(T)}s`} style={{ position: 'absolute', inset: 0, background: C.bg, overflow: 'hidden', color: C.hueso }}>
      <Particles T={T} F0={F0} K0={K0} />
      <Flow T={T} F0={F0} grid={grid} />
      <Chaos T={T} P0={P0} />
      <Familiar T={T} P0={P0} F0={F0} />
      <Headline T={T} P0={P0} R0={R0} />
      <Result T={T} R0={R0} />
      <Closing T={T} K0={K0} firma={firma} />
    </div>
  );
}

function N8nPedidoVideo() {
  const [t, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  return (
    <React.Fragment>
      <CompositionStage width={1080} height={1920} bg={C.bg} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK}>
        <Piece grid={t.grid} firma={t.firma} />
      </CompositionStage>
      <TweaksPanel>
        <TweakSection label="Video" />
        <TweakToggle label="Motion editor" value={t.motionEditor} onChange={v => setTweak('motionEditor', v)} />
        <TweakToggle label="Cuadrícula del lienzo" value={t.grid} onChange={v => setTweak('grid', v)} />
        <TweakToggle label="Firma «Construido con n8n»" value={t.firma} onChange={v => setTweak('firma', v)} />
      </TweaksPanel>
    </React.Fragment>
  );
}
window.N8nPedidoVideo = N8nPedidoVideo;
